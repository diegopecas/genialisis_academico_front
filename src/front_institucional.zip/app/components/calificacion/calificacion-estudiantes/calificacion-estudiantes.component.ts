import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from '../../../common/header/header.component';
import { ActividadesAcademicasService } from '../../../services/actividades-academicas.service';
import { ParametrosCalificacionesService } from '../../../services/parametros-calificaciones.service';
import { ValoresParametrosCalificacionesService } from '../../../services/valores-parametros-calificaciones.service';
import { CalificacionesService } from '../../../services/calificaciones.service';
import { TareasXSprintsService } from '../../../services/tareas-x-sprints.service';
import { TareasXSprintsXEstudianteService } from '../../../services/tareas-x-sprints-x-estudiante.service';
import { CalificacionContextService } from '../../../services/calificacion-context.service';
import { GruposService } from '../../../services/grupos.service';
import { AreasAcademicasService } from '../../../services/areas-academicas.service';
import { UtilService } from '../../../common/constantes/util.service';
import collect from 'collect.js';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-calificacion-estudiantes',
  templateUrl: './calificacion-estudiantes.component.html',
  styleUrl: './calificacion-estudiantes.component.scss',
  standalone: true,
  imports: [CommonModule, FormsModule, HeaderComponent]
})
export class CalificacionEstudiantesComponent implements OnInit {

  public titulo = "Registro de calificaciones";
  public grupo: any = null;
  public area: any = null;
  public actividadAcademica: any = null;
  public estudiantes: any[] = [];
  public estudiantesAusentes: any[] = [];
  public parametrosCalificaciones: any[] = [];
  public usuario: any = {};

  // Acordeón ausentes
  public ausentesExpandido: boolean = false;

  // Calificación masiva: valor elegido por parámetro antes de aplicar a todos
  public valoresMasivos: { [idParametro: string]: any } = {};
  public aplicandoMasivo: boolean = false;
  public parametroAplicando: any = null;
  public panelMasivoAbierto: boolean = true;

  // Observación general de la tarea
  public observacionTarea: string = '';

  // Horario
  public bloquesHorario: any[] = [];
  public horarioSeleccionado: any = null;

  // Huella del dispositivo (silenciosa)
  private huellaDispositivo: string = '';
  private userAgent: string = '';

  public idGrupo: string = '';
  public idArea: string = '';
  public idTareaSprint: string = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private gruposService: GruposService,
    private areasAcademicasService: AreasAcademicasService,
    private actividadesAcademicasService: ActividadesAcademicasService,
    private parametrosCalificacionesService: ParametrosCalificacionesService,
    private valoresParametrosCalificacionesService: ValoresParametrosCalificacionesService,
    private calificacionesService: CalificacionesService,
    private tareasXSprintsService: TareasXSprintsService,
    private tareasXSprintsXEstudianteService: TareasXSprintsXEstudianteService,
    private calificacionContext: CalificacionContextService,
    private utilService: UtilService
  ) {}

  ngOnInit(): void {
    this.usuario = this.utilService.obtenerUsuarioActual();
    this.generarHuellaDispositivo();

    this.route.params.subscribe(params => {
      this.idGrupo = params['idGrupo'];
      this.idArea = params['idArea'];
      this.idTareaSprint = params['idTareaSprint'];
      this.cargarDatos();
    });
  }

  public get esEvaluacion(): boolean {
    return !!(this.actividadAcademica && Number(this.actividadAcademica.es_evaluacion) === 1);
  }

  private cargarDatos(): void {
    this.gruposService.obtenerTodos().subscribe((resp: any) => {
      const grupos = resp.body || [];
      this.grupo = grupos.find((g: any) => g.id == this.idGrupo) || null;
      this.actualizarTitulo();
      this.cargarActividad();
    });

    this.areasAcademicasService.obtenerAreasAcademicasGrupo(this.idGrupo)
      .subscribe((resp: any) => {
        const areas = resp.body || [];
        this.area = areas.find((a: any) => a.id_area_academica == this.idArea) || null;
        this.actualizarTitulo();
      });

    this.cargarParametrosCalificaciones();
    this.cargarBloquesHorario();
  }

  /**
   * El título del header muestra el grupo y el área que se está calificando,
   * para no perder el contexto al entrar desde el listado.
   */
  private actualizarTitulo(): void {
    const partes: string[] = [];

    if (this.grupo && this.grupo.nombre) partes.push(this.grupo.nombre);
    if (this.area && this.area.nombre_area_academica) partes.push(this.area.nombre_area_academica);

    this.titulo = partes.length > 0
      ? 'Calificaciones: ' + partes.join(' - ')
      : 'Registro de calificaciones';
  }

  private cargarBloquesHorario(): void {
    const jsDay = new Date().getDay();
    const diaSemana = jsDay === 0 ? 7 : jsDay;
    this.bloquesHorario = this.calificacionContext.getHorariosAreaDia(this.idGrupo, this.idArea, diaSemana);
    this.horarioSeleccionado = this.calificacionContext.getBloqueActual(this.idGrupo, this.idArea);
  }

  private cargarParametrosCalificaciones(): void {
    this.parametrosCalificacionesService.obtenerTodos().subscribe((response: any) => {
      this.parametrosCalificaciones = response.body;
      this.cargarValoresParametros();
    });
  }

  private cargarValoresParametros(): void {
    this.valoresParametrosCalificacionesService.obtenerTodos().subscribe((responseVal: any) => {
      const valores = collect(responseVal.body);
      this.parametrosCalificaciones.forEach((pc: any) => {
        pc.valores = (valores.where("id_parametros_calificaciones", pc.id) as any).items
          .sort((a: any, b: any) => a.valor_cuantitativo - b.valor_cuantitativo);
      });

      // Los estudiantes y los parámetros se cargan en paralelo. Si los
      // estudiantes llegaron primero, sus parámetros quedaron sin valores y
      // las estrellas no se pintan, así que aquí se les completan.
      this.sincronizarValoresEnEstudiantes();
    });
  }

  /**
   * Copia los valores de cada parámetro global a los parámetros que cuelgan de
   * cada estudiante y resuelve cuál quedó seleccionado según su calificación.
   */
  private sincronizarValoresEnEstudiantes(): void {
    const todos = [...this.estudiantes, ...this.estudiantesAusentes];

    todos.forEach(estudiante => {
      (estudiante.parametrosCalificaciones || []).forEach((epc: any) => {
        if (!epc.valores || epc.valores.length === 0) {
          const global = this.parametrosCalificaciones.find((pc: any) => pc.id == epc.id);
          epc.valores = global && global.valores ? JSON.parse(JSON.stringify(global.valores)) : [];
        }

        if (epc.idValorSeleccionado && !epc.seleccionado) {
          epc.seleccionado = (epc.valores || [])
            .find((v: any) => v.id == epc.idValorSeleccionado);
        }
      });
    });
  }

  private cargarActividad(): void {
    this.actividadesAcademicasService.obtenerByGrupoArea(this.idGrupo, this.idArea)
      .subscribe((response: any) => {
        const actividades = response.body || [];
        const actividad = actividades.find((a: any) => a.id_tarea_x_sprint == this.idTareaSprint);
        if (actividad) {
          this.actividadAcademica = {
            ...actividad,
            titulo: this.limpiarHTML(actividad.titulo),
            descripcion: this.limpiarHTML(actividad.descripcion),
            materiales: this.limpiarHTML(actividad.materiales),
            nivel_uno: this.limpiarHTML(actividad.nivel_uno),
            nivel_dos: this.limpiarHTML(actividad.nivel_dos),
            indicador_logro_nombre: this.limpiarHTML(actividad.indicador_logro_nombre)
          };
          this.cargarVistaTarea();
          this.cargarObservacionTarea();
        }
      });
  }

  /**
   * Carga estudiantes (presentes y ausentes), calificaciones y observaciones
   * en una sola llamada al backend.
   */
  private cargarVistaTarea(): void {
    this.calificacionesService.obtenerVistaTarea(this.idGrupo, this.idTareaSprint)
      .subscribe((resp: any) => {
        const todos: any[] = resp.body || [];

        const presentes: any[] = [];
        const ausentes: any[] = [];

        todos.forEach((est: any) => {
          const procesado = this.procesarEstudiante(est);
          if (est.presente === 1) {
            presentes.push(procesado);
          } else {
            ausentes.push(procesado);
          }
        });

        this.estudiantes = presentes;
        this.estudiantesAusentes = ausentes;

        // Por si los valores de los parámetros llegaron antes que los estudiantes
        this.sincronizarValoresEnEstudiantes();
      });
  }

  /**
   * Toma un estudiante crudo del backend y le anida los parámetros de calificación
   * con su valor seleccionado (si lo tiene).
   */
  private procesarEstudiante(est: any): any {
    // Clonar parámetros para que cada estudiante tenga los suyos
    const parametrosCalificaciones = JSON.parse(
      JSON.stringify(this.parametrosCalificaciones)
    );

    // Mapear calificaciones existentes a los parámetros
    const calificaciones = est.calificaciones || [];
    parametrosCalificaciones.forEach((epc: any) => {
      // Se toma la ÚLTIMA coincidencia, no la primera: el backend las manda
      // ordenadas por fecha, así que si quedaran duplicados de una misma
      // calificación se muestra la más reciente, que es la nota vigente.
      const coincidencias = calificaciones.filter(
        (c: any) => c.id_parametro_calificacion == epc.id
      );
      const cal = coincidencias.length > 0 ? coincidencias[coincidencias.length - 1] : null;
      if (cal) {
        // Se guarda el id aparte: si los valores todavía no llegaron, el
        // seleccionado se resuelve después en sincronizarValoresEnEstudiantes
        epc.idValorSeleccionado = cal.id_valor_parametro_calificacion;
        epc.seleccionado = (epc.valores || []).find(
          (v: any) => v.id == cal.id_valor_parametro_calificacion
        );
        epc.guardado = cal.id;
      }
    });

    return {
      id_estudiante: est.id_estudiante,
      primer_nombre: est.primer_nombre,
      segundo_nombre: est.segundo_nombre,
      primer_apellido: est.primer_apellido,
      segundo_apellido: est.segundo_apellido,
      presente: est.presente,
      idTareaEstudiante: est.id_tarea_estudiante || null,
      observacion: est.observacion || '',
      observacionGuardada: est.observacion || '',
      parametrosCalificaciones: parametrosCalificaciones
    };
  }

  // ========== Observación general de la tarea ==========

  private cargarObservacionTarea(): void {
    this.tareasXSprintsService.obtenerById(this.idTareaSprint).subscribe((resp: any) => {
      const tarea = resp.body;
      if (tarea && tarea.length > 0) {
        this.observacionTarea = tarea[0].observaciones || '';
      }
    });
  }

  guardarObservacionTarea(): void {
    this.tareasXSprintsService.actualizarObservacion(this.idTareaSprint, this.observacionTarea)
      .subscribe({
        next: () => {},
        error: () => { Swal.fire({ toast: true, position: 'top-end', icon: 'error', title: 'Error al guardar observación', showConfirmButton: false, timer: 2000 }); }
      });
  }

  // ========== Observaciones por estudiante ==========

  guardarObservacionEstudiante(estudiante: any): void {
    if (estudiante.observacion === estudiante.observacionGuardada) return;

    this.tareasXSprintsXEstudianteService.actualizarObservacion(
      this.idTareaSprint,
      estudiante.id_estudiante,
      estudiante.observacion
    ).subscribe({
      next: (resp: any) => {
        estudiante.observacionGuardada = estudiante.observacion;
        if (resp.id) {
          estudiante.idTareaEstudiante = resp.id;
        }
      },
      error: () => { Swal.fire({ toast: true, position: 'top-end', icon: 'error', title: 'Error al guardar observación', showConfirmButton: false, timer: 2000 }); }
    });
  }

  // ========== Calificación ==========

  private limpiarHTML(html: string): string {
    if (!html) return '';
    let cleanHtml = html
      .replace(/ style="[^"]*"/gi, '')
      .replace(/ class="[^"]*"/gi, '')
      .replace(/<font[^>]*>/gi, '')
      .replace(/<\/font>/gi, '')
      .replace(/<span[^>]*>/gi, '')
      .replace(/<\/span>/gi, '')
      .replace(/&nbsp;/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    cleanHtml = cleanHtml.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    cleanHtml = cleanHtml.replace(/__(.*?)__/g, '<em>$1</em>');
    return cleanHtml;
  }

  calificar(valorParametro: any, parametro: any, estudiante: any): void {
    parametro.seleccionado = valorParametro;
    parametro.idValorSeleccionado = valorParametro.id;

    // guardado es el UUID de la calificación, no un número: compararlo contra 0
    // daba siempre falso y por eso cada clic insertaba una fila nueva en vez de
    // actualizar la que ya existía.
    if (parametro.guardado) {
      this.actualizarCalificacion(parametro.guardado, valorParametro.id);
    } else {
      this.crearCalificacion(
        estudiante.id_estudiante,
        this.actividadAcademica.id_tarea_x_sprint,
        parametro,
        valorParametro.id
      );
      // Crear registro en tareas_x_sprints_x_estudiante si no existe
      if (!estudiante.idTareaEstudiante) {
        this.tareasXSprintsXEstudianteService.crear(
          this.actividadAcademica.id_tarea_x_sprint,
          estudiante.id_estudiante
        ).subscribe((resp: any) => {
          if (resp.id) {
            estudiante.idTareaEstudiante = resp.id;
          }
        });
      }
    }
  }

  private actualizarCalificacion(idCalificacion: string, idValorParametro: string): void {
    this.calificacionesService.actualizarCalificacion(idCalificacion, idValorParametro)
      .subscribe({
        next: () => {},
        error: () => { Swal.fire({ toast: true, position: 'top-end', icon: 'error', title: 'Error al guardar calificación', showConfirmButton: false, timer: 2000 }); }
      });
  }

  private crearCalificacion(idEstudiante: string, idTareaSprint: string, parametro: any, idValorParametro: string): void {
    this.calificacionesService.calificar(
      idEstudiante,
      idTareaSprint,
      parametro.id,
      idValorParametro
    ).subscribe({
      next: (response: any) => {
        // La respuesta es { id: '...' }; guardar el objeto entero hacía que
        // el siguiente clic no encontrara el id para actualizar
        parametro.guardado = response && response.id ? response.id : response;
      },
      error: () => { Swal.fire({ toast: true, position: 'top-end', icon: 'error', title: 'Error al guardar calificación', showConfirmButton: false, timer: 2000 }); }
    });
  }

  // ========== Calificación masiva ==========

  togglePanelMasivo(): void {
    this.panelMasivoAbierto = !this.panelMasivoAbierto;
  }

  /** Marca el valor que se va a aplicar a todos para ese parámetro (todavía no guarda) */
  seleccionarValorMasivo(parametro: any, valorParametro: any): void {
    this.valoresMasivos[parametro.id] = valorParametro;
  }

  valorMasivoSeleccionado(parametro: any): any {
    return this.valoresMasivos[parametro.id] || null;
  }

  /**
   * Parámetros que todavía tienen estudiantes sin calificar.
   * Los que ya están completos desaparecen del panel, y cuando no queda
   * ninguno el panel entero deja de mostrarse.
   */
  get parametrosMasivosPendientes(): any[] {
    return this.parametrosCalificaciones
      .filter(parametro => this.pendientesPorParametro(parametro) > 0);
  }

  /** Cuántos estudiantes quedarían calificados si se aplica el valor de ese parámetro */
  pendientesPorParametro(parametro: any): number {
    return this.estudiantesParaMasivo
      .filter(est => !this.tieneCalificacion(est, parametro.id))
      .length;
  }

  /**
   * Estudiantes a los que aplica la calificación masiva: únicamente los que
   * están presentes en ese momento. Los ausentes quedan por fuera y, si hay
   * que calificarlos, se hace uno por uno desde su acordeón.
   */
  private get estudiantesParaMasivo(): any[] {
    return this.estudiantes;
  }

  private tieneCalificacion(estudiante: any, idParametro: any): boolean {
    const parametro = (estudiante.parametrosCalificaciones || [])
      .find((p: any) => p.id == idParametro);
    return !!(parametro && parametro.seleccionado);
  }

  /**
   * Aplica el valor elegido a los estudiantes presentes que aún no tienen
   * nota en ese parámetro. Los que ya están calificados no se tocan, y los
   * ausentes nunca entran.
   */
  aplicarATodos(parametro: any): void {
    const valorParametro = this.valoresMasivos[parametro.id];
    if (!valorParametro || !this.actividadAcademica) return;

    const pendientes = this.estudiantesParaMasivo
      .filter(est => !this.tieneCalificacion(est, parametro.id));

    if (pendientes.length === 0) {
      Swal.fire({ toast: true, position: 'top-end', icon: 'info', title: 'Todos ya tienen calificación en ' + parametro.nombre, showConfirmButton: false, timer: 2500 });
      return;
    }

    this.aplicandoMasivo = true;
    this.parametroAplicando = parametro.id;

    this.calificacionesService.calificarLote(
      this.actividadAcademica.id_tarea_x_sprint,
      parametro.id,
      valorParametro.id,
      pendientes.map(est => est.id_estudiante)
    ).subscribe({
      next: (respuesta: any) => {
        this.aplicandoMasivo = false;
        this.parametroAplicando = null;
        const creadas = (respuesta && respuesta.creadas) || [];

        creadas.forEach((creada: any) => {
          const estudiante = this.estudiantesParaMasivo
            .find(est => est.id_estudiante == creada.id_estudiante);
          if (!estudiante) return;

          const parametroEstudiante = (estudiante.parametrosCalificaciones || [])
            .find((p: any) => p.id == parametro.id);
          if (parametroEstudiante) {
            parametroEstudiante.idValorSeleccionado = valorParametro.id;
            // Se busca contra los valores del parámetro global: los del
            // estudiante podrían no estar cargados todavía
            parametroEstudiante.seleccionado = (parametro.valores || [])
              .find((v: any) => v.id == valorParametro.id);
            parametroEstudiante.guardado = creada.id_calificacion;
          }

          if (!estudiante.idTareaEstudiante && creada.id_tarea_estudiante) {
            estudiante.idTareaEstudiante = creada.id_tarea_estudiante;
          }
        });

        Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: creadas.length + ' calificados en ' + parametro.nombre, showConfirmButton: false, timer: 2000 });
      },
      error: () => {
        this.aplicandoMasivo = false;
        this.parametroAplicando = null;
        Swal.fire({ toast: true, position: 'top-end', icon: 'error', title: 'Error al calificar en lote', showConfirmButton: false, timer: 2000 });
      }
    });
  }

  /** Nombre a mostrar del docente: el sobrenombre si existe, si no el primer nombre. */
  nombreDocente(): string {
    const sobrenombre = (this.usuario?.sobrenombre || '').trim();
    return sobrenombre || this.usuario?.primer_nombre || '';
  }

  iniciarTarea(): void {
    this.tareasXSprintsService.iniciarTarea(
      this.actividadAcademica.id_tarea_x_sprint,
      this.usuario.id_docente,
      this.horarioSeleccionado,
      { userAgent: this.userAgent, huella: this.huellaDispositivo }
    ).subscribe((response: any) => {
      this.actividadAcademica.id_docente_inicia = this.usuario.id_docente;
    });
  }

  finalizarTarea(): void {
    this.tareasXSprintsService.finalizarTarea(
      this.actividadAcademica.id_tarea_x_sprint,
      this.usuario.id_docente
    ).subscribe((response: any) => {
      this.router.navigate(['/calificacion/grupo', this.idGrupo, 'area', this.idArea]);
    });
  }

  toggleAusentes(): void {
    this.ausentesExpandido = !this.ausentesExpandido;
  }

  trackByEstudiante(index: number, est: any): any {
    return est.id_estudiante;
  }

  get rutaRegresar(): string {
    return '/calificacion/grupo/' + this.idGrupo + '/area/' + this.idArea;
  }

  // ========== Huella del dispositivo (silenciosa) ==========

  private generarHuellaDispositivo(): void {
    this.userAgent = navigator.userAgent || '';
    try {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (ctx) {
        canvas.width = 200;
        canvas.height = 50;
        ctx.textBaseline = 'top';
        ctx.font = '14px Arial';
        ctx.fillStyle = '#f60';
        ctx.fillRect(125, 1, 62, 20);
        ctx.fillStyle = '#069';
        ctx.fillText('Lumen fingerprint', 2, 15);
        ctx.fillStyle = 'rgba(102, 204, 0, 0.7)';
        ctx.fillText('Lumen fingerprint', 4, 17);
        const dataUrl = canvas.toDataURL();
        this.huellaDispositivo = this.hashSimple(dataUrl + '|' + this.userAgent + '|' + screen.width + 'x' + screen.height + '|' + navigator.language + '|' + new Date().getTimezoneOffset());
      }
    } catch (e) {
      this.huellaDispositivo = this.hashSimple(this.userAgent + '|' + screen.width + 'x' + screen.height);
    }
  }

  private hashSimple(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16).padStart(8, '0');
  }
}