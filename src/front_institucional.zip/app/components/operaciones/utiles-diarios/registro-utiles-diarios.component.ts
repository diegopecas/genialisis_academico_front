import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from '../../../common/header/header.component';
import { RegistroUtilesDiariosService } from '../../../services/utiles-diarios-registro.service';
import { GruposService } from '../../../services/grupos.service';
import { UtilService } from '../../../common/constantes/util.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-registro-utiles-diarios',
  templateUrl: './registro-utiles-diarios.component.html',
  styleUrl: './registro-utiles-diarios.component.scss',
  standalone: true,
  imports: [CommonModule, FormsModule, HeaderComponent]
})
export class RegistroUtilesDiariosComponent implements OnInit, OnDestroy {

  titulo = "Útiles y Accesorios Diarios";

  public grupos = [] as any[];
  // null significa todos los grupos: la docente ve el jardin completo y
  // filtra en pantalla.
  public idGrupo: any = null;

  public busquedaEstudiante: string = '';
  public fecha: string = '';

  // Los que todavía no han salido. Ojo: la grilla nunca muestra a quien no
  // tenga entrada registrada ese día, eso lo filtra el backend siempre.
  public soloPresentes: boolean = false;

  // 'entrada' edita lo que el niño trajo, 'salida' lo que se lleva.
  public modo: string = 'entrada';

  public estudiantes = [] as any[];
  public columnas = [] as any[];
  public filas = [] as any[];

  public cargando: boolean = false;
  public guardando: boolean = false;

  // Cambios pendientes de guardar, indexados por id de fila para que marcar
  // dos veces el mismo check no mande dos cambios.
  // Cada pendiente guarda el estado nuevo de esa fila: 1 lo trajo, 0 no lo
  // trajo, null todavia sin verificar.
  private pendientes = new Map<string, number | null>();

  // Filas que ya existen en la base y la usuaria quito con la equis. Se
  // borran cuando presione Grabar, no antes.
  private eliminados: string[] = [];

  // Notas escritas y todavía sin grabar, por id de fila.
  private notasPendientes = new Map<string, string | null>();

  // Consecutivo para los ids temporales de los utiles agregados con el +.
  private consecutivoNuevo = 0;

  // ==== AUTOGUARDADO ====
  // Los cambios se graban solos segundo y medio despues de que la usuaria
  // pare de marcar, sin spinner. El boton de abajo sigue existiendo para
  // grabar de una y ver la confirmacion.
  private temporizador: any = null;
  private readonly esperaAutoguardado = 1500;

  // 'limpio' | 'pendiente' | 'guardando' | 'guardado' | 'error'
  public estadoGuardado: string = 'limpio';
  public horaUltimoGuardado: string = '';
  private guardadoEnVuelo = false;

  constructor(
    private registroUtilesDiariosService: RegistroUtilesDiariosService,
    private gruposService: GruposService,
    private utilService: UtilService
  ) {}

  ngOnInit(): void {
    this.fecha = this.obtenerFechaActual();
    this.consultaGrupos();
    this.consultarDia();
  }

  /**
   * Fecha actual en formato YYYY-MM-DD usando hora local (no UTC).
   * No usar new Date().toISOString().split('T')[0] porque convierte a UTC y desfasa el día.
   */
  private obtenerFechaActual(): string {
    const ahora = new Date();
    const anio = ahora.getFullYear();
    const mes = String(ahora.getMonth() + 1).padStart(2, '0');
    const dia = String(ahora.getDate()).padStart(2, '0');
    return `${anio}-${mes}-${dia}`;
  }

  consultaGrupos() {
    this.gruposService.obtenerTodos().subscribe({
      next: (response: any) => {
        this.grupos = (response.body as any[]) || [];
      },
      error: () => {
        this.grupos = [];
      }
    });
  }

  // silencioso en true recarga sin spinner. Se usa despues de un autoguardado
  // que creo o borro utiles, porque esas filas necesitan su id real.
  consultarDia(silencioso: boolean = false) {
    if (!this.fecha) {
      return;
    }

    if (this.hayPendientes) {
      Swal.fire('Atención', 'Hay cambios sin guardar. Grábalos antes de cambiar de grupo o fecha.', 'warning');
      return;
    }

    this.cargando = !silencioso;

    if (!silencioso) {
      // Dia nuevo en pantalla: el indicador arranca en blanco.
      this.estadoGuardado = 'limpio';
    }

    const idUsuario = this.utilService.obtenerIdUsuarioActual();

    this.registroUtilesDiariosService.obtenerDiaGrupo(this.idGrupo, this.fecha, this.soloPresentes, idUsuario, silencioso).subscribe({
      next: (respuesta: any) => {
        this.estudiantes = respuesta.estudiantes || [];
        this.columnas = respuesta.columnas || [];
        this.filas = respuesta.filas || [];
        this.cargando = false;
      },
      error: () => {
        this.cargando = false;
        if (!silencioso) {
          Swal.fire('Error', 'No se pudo cargar el registro del día', 'error');
        }
      }
    });
  }

  cambiarModo(modo: string) {
    if (this.hayPendientes) {
      Swal.fire('Atención', 'Hay cambios sin guardar. Grábalos antes de cambiar de entrada a salida.', 'warning');
      return;
    }
    this.modo = modo;
  }

  // Estudiantes que coinciden con la busqueda por nombre.
  get estudiantesFiltrados(): any[] {
    const q = (this.busquedaEstudiante || '').trim().toLowerCase();
    if (q.length === 0) {
      return this.estudiantes;
    }
    return this.estudiantes.filter((e: any) => this.nombreEstudiante(e).toLowerCase().includes(q));
  }

  // Con "Todos" los ninos se muestran en secciones por grupo. Con un grupo
  // puntual no hay secciones, porque ya se esta filtrando arriba.
  get secciones(): any[] {
    const lista = this.estudiantesFiltrados;

    if (this.idGrupo) {
      return [{ id_grupo: null, nombre_grupo: null, estudiantes: lista }];
    }

    const mapa: { [id: string]: any } = {};
    lista.forEach((e: any) => {
      const id = e.id_grupo || 'sin-grupo';
      if (!mapa[id]) {
        mapa[id] = {
          id_grupo: e.id_grupo,
          nombre_grupo: e.nombre_grupo || 'Sin grupo',
          orden_grupo: e.orden_grupo ?? 9999,
          estudiantes: []
        };
      }
      mapa[id].estudiantes.push(e);
    });

    return Object.values(mapa).sort((a: any, b: any) => {
      if (a.orden_grupo !== b.orden_grupo) return a.orden_grupo - b.orden_grupo;
      return String(a.nombre_grupo).localeCompare(String(b.nombre_grupo));
    });
  }

  get totalEstudiantes(): number {
    return this.estudiantes.length;
  }

  // Todas las filas de un niño, tanto de columna como sueltas. Es lo que
  // pinta la tarjeta de la vista móvil.
  obtenerFilasEstudiante(idEstudiante: any) {
    return this.filas.filter((f: any) => f.id_estudiante === idEstudiante);
  }

  // Estado de una fila: 1 lo trajo, 0 no lo trajo, null sin verificar.
  estado(fila: any): number | null {
    if (!fila) return null;

    if (this.pendientes.has(fila.id)) {
      return this.pendientes.get(fila.id) ?? null;
    }

    const valor = this.modo === 'entrada' ? fila.trajo : fila.regreso;
    if (valor === null || valor === undefined || valor === '') return null;
    return valor == 1 ? 1 : 0;
  }

  estaMarcado(fila: any): boolean {
    return this.estado(fila) === 1;
  }

  esNegativo(fila: any): boolean {
    return this.estado(fila) === 0;
  }

  sinVerificar(fila: any): boolean {
    return this.estado(fila) === null;
  }

  // En salida no se puede marcar lo que no entró en la mañana.
  estaBloqueado(fila: any): boolean {
    if (!fila) return true;
    return this.modo === 'salida' && fila.trajo != 1;
  }

  // Al tocar la celda cicla: sin verificar -> lo trajo -> no lo trajo -> ...
  // Arranca la cuenta regresiva del autoguardado. Si se sigue marcando, se
  // reinicia, para que salga una sola peticion con todo junto.
  private programarAutoguardado() {
    this.estadoGuardado = 'pendiente';

    if (this.temporizador) {
      clearTimeout(this.temporizador);
    }

    this.temporizador = setTimeout(() => this.guardar(true), this.esperaAutoguardado);
  }

  ngOnDestroy(): void {
    if (this.temporizador) {
      clearTimeout(this.temporizador);
    }
  }

  alternar(fila: any) {
    if (!fila || this.estaBloqueado(fila)) return;

    const actual = this.estado(fila);
    let siguiente: number | null;

    if (actual === null) {
      siguiente = 1;
    } else if (actual === 1) {
      siguiente = 0;
    } else {
      siguiente = null;
    }

    this.pendientes.set(fila.id, siguiente);
    this.programarAutoguardado();
  }

  private marcarFilas(filas: any[], valor: number | null) {
    filas.forEach((fila: any) => {
      if (this.estaBloqueado(fila)) return;
      this.pendientes.set(fila.id, valor);
    });
    this.programarAutoguardado();
  }

  // ---- Marcar todo: los tres niveles ----

  todoMarcado(): boolean {
    const editables = this.filas.filter((f: any) => !this.estaBloqueado(f));
    return editables.length > 0 && editables.every((f: any) => this.estaMarcado(f));
  }

  alternarTodo() {
    this.marcarFilas(this.filas, this.todoMarcado() ? null : 1);
  }

  columnaMarcada(idUtil: any): boolean {
    const editables = this.filas.filter((f: any) => f.id_util_diario === idUtil && !this.estaBloqueado(f));
    return editables.length > 0 && editables.every((f: any) => this.estaMarcado(f));
  }

  alternarColumna(idUtil: any) {
    const valor = this.columnaMarcada(idUtil) ? null : 1;
    this.marcarFilas(this.filas.filter((f: any) => f.id_util_diario === idUtil), valor);
  }

  estudianteMarcado(idEstudiante: any): boolean {
    const editables = this.obtenerFilasEstudiante(idEstudiante).filter((f: any) => !this.estaBloqueado(f));
    return editables.length > 0 && editables.every((f: any) => this.estaMarcado(f));
  }

  alternarEstudiante(idEstudiante: any) {
    const valor = this.estudianteMarcado(idEstudiante) ? null : 1;
    this.marcarFilas(this.obtenerFilasEstudiante(idEstudiante), valor);
  }

  // Los eliminados tambien cuentan como cambio sin guardar, aunque no dejen
  // pendiente en el mapa.
  reintentarGuardado() {
    this.guardar(true);
  }

  get textoEstadoGuardado(): string {
    switch (this.estadoGuardado) {
      case 'pendiente': return 'Sin guardar...';
      case 'guardando': return 'Guardando...';
      case 'guardado': return `Guardado ${this.horaUltimoGuardado}`;
      case 'error': return 'No se pudo guardar';
      default: return '';
    }
  }

  get hayPendientes(): boolean {
    return this.pendientes.size > 0 || this.eliminados.length > 0 || this.notasPendientes.size > 0;
  }

  get totalPendientes(): number {
    return this.pendientes.size + this.eliminados.length;
  }

  // silencioso en true es el autoguardado: sin spinner y sin toast. En false
  // es el boton, que sí confirma en pantalla.
  guardar(silencioso: boolean = false) {
    // Se puede grabar aunque no haya cambios: que todos hayan traído todo es
    // un resultado válido y la docente necesita poder confirmarlo. En ese caso
    // se mandan los valores tal como están, que además deja registrado quién
    // revisó el día y cuándo.
    // Si ya hay una guardando, se reprograma en vez de mandar otra encima.
    if (this.guardadoEnVuelo) {
      this.programarAutoguardado();
      return;
    }

    if (this.temporizador) {
      clearTimeout(this.temporizador);
      this.temporizador = null;
    }

    const cambios = [] as any[];
    const nuevos = [] as any[];

    const agregar = (fila: any, valor: number | null) => {
      if (!fila) return;

      if (fila.esNuevo) {
        nuevos.push({
          id_estudiante: fila.id_estudiante,
          fecha: this.fecha,
          id_util_diario: fila.id_util_diario || null,
          nombre_libre: fila.nombre_libre || null,
          valor: valor,
          observacion: this.notaDe(fila) || null
        });
      } else {
        const cambio: any = { id: fila.id, valor: valor };

        // La clave observacion solo viaja si se editó, para no pisar la nota
        // que ya estaba guardada.
        if (this.notasPendientes.has(fila.id)) {
          cambio.observacion = this.notasPendientes.get(fila.id);
        }

        cambios.push(cambio);
      }
    };

    if (this.pendientes.size > 0) {
      this.pendientes.forEach((valor, id) => {
        agregar(this.filas.find((f: any) => f.id === id), valor);
      });
    } else {
      this.filas.forEach((fila: any) => {
        if (this.estaBloqueado(fila)) {
          return;
        }
        agregar(fila, this.estado(fila));
      });
    }

    if (cambios.length === 0 && nuevos.length === 0 && this.eliminados.length === 0) {
      if (!silencioso) {
        Swal.fire('Sin datos', 'No hay útiles que confirmar en este grupo.', 'info');
      }
      return;
    }

    this.guardando = !silencioso;
    this.guardadoEnVuelo = true;
    this.estadoGuardado = 'guardando';
    const idUsuario = this.utilService.obtenerIdUsuarioActual();
    const eraConfirmacion = this.pendientes.size === 0;

    const huboNuevosOBorrados = nuevos.length > 0 || this.eliminados.length > 0;

    this.registroUtilesDiariosService.guardarLote(this.modo, cambios, idUsuario, nuevos, this.eliminados, silencioso).subscribe({
      next: () => {
        // Se refleja en las filas que ya están en pantalla para no tener que
        // recargar toda la grilla.
        this.pendientes.forEach((valor, id) => {
          const fila = this.filas.find((f: any) => f.id === id);
          if (fila) {
            if (this.modo === 'entrada') {
              fila.trajo = valor;
            } else {
              fila.regreso = valor;
            }
          }
        });
        this.notasPendientes.forEach((nota, id) => {
          const fila = this.filas.find((f: any) => f.id === id);
          if (fila) {
            fila.observacion = nota;
          }
        });

        this.pendientes.clear();
        this.notasPendientes.clear();
        this.eliminados = [];
        this.guardando = false;
        this.guardadoEnVuelo = false;
        this.estadoGuardado = 'guardado';
        this.horaUltimoGuardado = new Date().toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' });

        // Los agregados y los quitados necesitan recargar, porque las filas
        // nuevas todavía no tienen su id real de la base.
        if (huboNuevosOBorrados) {
          this.consultarDia(silencioso);
        }

        if (!silencioso) {
          Swal.fire({
            toast: true,
            position: 'top-end',
            icon: 'success',
            title: eraConfirmacion ? 'Día confirmado' : 'Cambios guardados',
            showConfirmButton: false,
            timer: 2500
          });
        }
      },
      error: () => {
        this.guardando = false;
        this.guardadoEnVuelo = false;
        this.estadoGuardado = 'error';

        // Los cambios NO se pierden: siguen en la cola. Si fue el
        // autoguardado, reintenta solo; si fue el botón, la usuaria ya vio el
        // error del interceptor y puede volver a darle.
        if (silencioso) {
          this.temporizador = setTimeout(() => this.guardar(true), 8000);
        }
      }
    });
  }

  // Un solo paso: se escribe el nombre y listo. Antes había que pasar por un
  // select con todo el catálogo, que no aportaba nada porque esos útiles ya
  // son columna de la grilla.
  // Un solo paso: se escribe el nombre y listo. El útil se agrega solo en
  // pantalla, con un id temporal; a la base entra cuando se presione Grabar.
  // Antes esto iba al backend de una, y quedaba grabado aunque la usuaria
  // cerrara sin guardar.
  async agregarUtil(estudiante: any) {
    const { value: texto } = await Swal.fire({
      title: `Agregar a ${estudiante.primer_nombre}`,
      input: 'text',
      inputPlaceholder: 'Ej: Inhalador',
      showCancelButton: true,
      confirmButtonText: 'Agregar',
      cancelButtonText: 'Cancelar'
    });

    if (!texto || texto.trim() === '') return;

    const nombre = texto.trim();
    const yaEsta = this.filas.some((f: any) =>
      f.id_estudiante === estudiante.id_estudiante &&
      String(f.nombre || '').trim().toLowerCase() === nombre.toLowerCase()
    );

    if (yaEsta) {
      Swal.fire('Atención', `"${nombre}" ya está en la lista de ${estudiante.primer_nombre}.`, 'info');
      return;
    }

    this.consecutivoNuevo++;
    const idTemporal = `nuevo-${this.consecutivoNuevo}`;

    this.filas.push({
      id: idTemporal,
      esNuevo: true,
      id_estudiante: estudiante.id_estudiante,
      id_util_diario: null,
      nombre_libre: nombre,
      nombre: nombre,
      icono: null,
      trajo: null,
      regreso: null,
      observacion: null,
      orden: 999
    });

    // Entra marcado como que sí lo trajo, que es la razón por la que se
    // agrega, y queda pendiente igual que cualquier otro cambio.
    this.pendientes.set(idTemporal, 1);
    this.programarAutoguardado();
  }

  async quitarSuelto(fila: any) {
    const result = await Swal.fire({
      title: '¿Quitar útil?',
      text: `Se quitará "${fila.nombre}" del día. No le aparecerá mañana.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Sí, quitar',
      cancelButtonText: 'Cancelar'
    });

    if (!result.isConfirmed) return;

    // Solo se saca de la pantalla. Si ya existía en la base, se anota para
    // borrarla al presionar Grabar.
    if (!fila.esNuevo) {
      this.eliminados.push(fila.id);
    }

    this.filas = this.filas.filter((f: any) => f.id !== fila.id);
    this.pendientes.delete(fila.id);
    this.programarAutoguardado();
  }

  // Horas de todas las entradas y salidas del niño ese día, para mostrarlas
  // debajo del nombre. Un niño puede entrar y salir varias veces.
  // Nota que se ve hoy en el chip: la que se acabó de escribir si hay, o la
  // que ya estaba guardada.
  notaDe(fila: any): string {
    if (!fila) return '';
    if (this.notasPendientes.has(fila.id)) {
      return this.notasPendientes.get(fila.id) || '';
    }
    return fila.observacion || '';
  }

  // Nota corta por útil, para cosas como "llegó rota" o "sin cuchara". Máximo
  // 200 caracteres: es una nota, no una observación del estudiante.
  async editarNota(fila: any, evento: Event) {
    evento.stopPropagation();

    const { value: texto } = await Swal.fire({
      title: fila.nombre,
      input: 'text',
      inputLabel: 'Nota (opcional)',
      inputValue: this.notaDe(fila),
      inputPlaceholder: 'Ej: llegó rota',
      inputAttributes: { maxlength: '200' },
      showCancelButton: true,
      confirmButtonText: 'Guardar nota',
      cancelButtonText: 'Cancelar'
    });

    if (texto === undefined) return;

    const nota = String(texto).trim();
    this.notasPendientes.set(fila.id, nota === '' ? null : nota);

    // La nota es un cambio como cualquier otro: si la fila no tenía nada
    // pendiente, se registra con el estado que ya tiene para que entre en el
    // mismo guardado.
    if (!this.pendientes.has(fila.id)) {
      this.pendientes.set(fila.id, this.estado(fila));
    }

    this.programarAutoguardado();
  }

  jornadasTexto(estudiante: any): string {
    const jornadas = String(estudiante?.jornadas ?? '').trim();
    if (!jornadas) return '';

    return jornadas
      .split('|')
      .map((j: string) => j.trim().replace(/-\s*$/, '→'))
      .join(' · ');
  }

  nombreEstudiante(estudiante: any): string {
    return [
      estudiante.primer_nombre,
      estudiante.segundo_nombre,
      estudiante.primer_apellido,
      estudiante.segundo_apellido
    ].filter(p => !!p).join(' ');
  }

  // Un niño que trajo algo y no se lo lleva. Solo aplica en modo salida.
  tieneFaltantes(idEstudiante: any): boolean {
    if (this.modo !== 'salida') return false;

    return this.filas.some((f: any) => {
      if (f.id_estudiante !== idEstudiante || f.trajo != 1) return false;
      return this.esNegativo(f);
    });
  }
}
