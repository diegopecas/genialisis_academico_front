import {
  HttpClient,
  HttpErrorResponse,
  HttpParams,
  HttpResponse,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Observable, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { httpOptions } from './http';
import { UtilService } from '../common/constantes/util.service';

@Injectable({
  providedIn: 'root'
})
export class AsistenciaEstudiantesService {

  private servicio = environment.api + 'asistencia-estudiantes';
  private servicioIngreso = environment.api + 'asistencia-estudiantes-ingresos';
  private servicioNoIngreso = environment.api + 'asistencia-estudiantes-no-ingresos';
  private servicioSalida = environment.api + 'asistencia-estudiantes-salidas';
  private servicioNoSalida = environment.api + 'asistencia-estudiantes-no-salidas';

  constructor(private http: HttpClient,
    private utilService: UtilService
  ) { }

  obtenerTodos() {
    return this.http
      .get<HttpResponse<Object>>(this.servicio, { observe: 'response' })
      .pipe(
        tap((response: HttpResponse<Object>) => {
          let respuesta: any = response.body;
          if (respuesta.error) {
            throw respuesta.error;
          }
          return response;
        }),
        catchError(this.handleError)
      );
  }

  obtenerNoIngresos() {

    return this.http
      .get<HttpResponse<Object>>(this.servicioNoIngreso, { observe: 'response' })
      .pipe(
        tap((response: HttpResponse<Object>) => {
          let respuesta: any = response.body;
          if (respuesta.error) {
            throw respuesta.error;
          }
          return response;
        }),
        catchError(this.handleError)
      );
  }

  // El back devuelve un objeto con dos listas:
  //   no_salidas: los que estan adentro (ingresaron hoy y no han salido)
  //   salidas:    los que ya se fueron hoy
  // Antes devolvia un arreglo plano con los de adentro.
  obtenerNoSalidas() {
    return this.http
      .get<HttpResponse<Object>>(this.servicioNoSalida, { observe: 'response' })
      .pipe(
        tap((response: HttpResponse<Object>) => {
          let respuesta: any = response.body;
          if (respuesta.error) {
            throw respuesta.error;
          }
          return response;
        }),
        catchError(this.handleError)
      );
  }

  // utilesDiarios es opcional: es lo que la docente marco en el panel. Quien
  // ya llamaba este metodo con dos parametros sigue funcionando igual.
  // notificar es opcional: indica si este endpoint debe avisarle al portal de
  // padres. Se manda en false cuando enseguida se van a ejecutar cobros, para
  // que sea el motor de cobros el que notifique y el mensaje los incluya.
  // Quien ya llamaba este metodo con dos o tres parametros sigue igual.
  // hora es opcional (HH:MM o HH:MM:SS): es la que la usuaria puede corregir
  // en el panel y la misma con la que se evaluan los cobros. Si no se manda,
  // el backend guarda la hora del servidor, como hacia antes.
  // idColaborador e idPersona son opcionales: el colaborador que recibe al
  // nino y la persona que lo trae. Quien ya llamaba sin ellos sigue igual.
  registroIngreso(id: any, observacion: any, utilesDiarios: any[] = [], notificar: boolean = true, hora: string | null = null, idColaborador: string | null = null, idPersona: string | null = null) {
    const id_usuario = this.utilService.obtenerIdUsuarioActual();
    const body = JSON.stringify({ id_estudiante: id, observacion: observacion, id_usuario: id_usuario, utiles_diarios: utilesDiarios, notificar: notificar, hora: hora, id_colaborador_recibe: idColaborador, id_persona_entrega: idPersona });

    return this.http.post<any>(this.servicio, body, httpOptions).pipe(
      tap((respuesta: any) => {
        //Se valida que si existe un mensaje de error
        if (respuesta.error) {
          console.log(respuesta);
          throw respuesta.error;
        }
        console.log(respuesta);
        return respuesta;
      }),
      catchError(this.handleError)
    );
  }

  // inventarioNoRegresa es opcional: son los ids de inventario_diario que el
  // nino NO se lleva. Quien ya llamaba este metodo con dos parametros sigue
  // funcionando igual.
  // utilesNoRegresa es opcional: son los ids del registro de utiles que el
  // nino NO se lleva. Quien ya llamaba con dos parametros sigue igual.
  // notificar: mismo criterio que en registroIngreso.
  // hora: mismo criterio que en registroIngreso.
  // idColaborador e idPersona: el colaborador que entrega al nino y la
  // persona que lo recoge. Opcionales, igual que en registroIngreso.
  registroSalida(id: any, observacion: any, utilesNoRegresa: any[] = [], notificar: boolean = true, hora: string | null = null, idColaborador: string | null = null, idPersona: string | null = null) {
    const id_usuario = this.utilService.obtenerIdUsuarioActual();
    const body = JSON.stringify({ id: id, observacion: observacion, id_usuario: id_usuario, utiles_no_regresa: utilesNoRegresa, notificar: notificar, hora: hora, id_colaborador_entrega: idColaborador, id_persona_recoge: idPersona });
    console.log("registroSalida", body)
    return this.http.put<any>(this.servicio, body, httpOptions).pipe(
      tap((respuesta: any) => {
        //Se valida que si existe un mensaje de error
        if (respuesta.error) {
          console.log(respuesta);
          throw respuesta.error;
        }
        console.log(respuesta);
        return respuesta;
      }),
      catchError(this.handleError)
    );
  }
  verificarAsistenciaEstudiante(elemento: any) {
    const body = JSON.stringify(elemento);
    return this.http.post<any>(this.servicio + '/verificar-x-dia', body, httpOptions).pipe(
      tap((respuesta: any) => {
        if (respuesta.error) throw respuesta.error;
        return respuesta;
      }),
      catchError(this.handleError)
    );
  }
  obtenerAsistenciaMensual(consulta: any) {
    const body = JSON.stringify(consulta);
    return this.http.post<any>(this.servicio + '/mensual', body, httpOptions).pipe(
      tap((respuesta: any) => {
        if (respuesta.error) throw respuesta.error;
        return respuesta;
      }),
      catchError(this.handleError)
    );
  }
  obtenerResumenAsistenciaPorGrupo(idGrupo: string, fechaInicio: string, fechaFin: string) {
    const params = new HttpParams()
      .set('fecha_inicio', fechaInicio)
      .set('fecha_fin', fechaFin);

    return this.http
      .get<HttpResponse<Object>>(`${this.servicio}/resumen-grupo/${idGrupo}`, {
        params,
        observe: 'response'
      })
      .pipe(
        tap((response: HttpResponse<Object>) => {
          let respuesta: any = response.body;
          if (respuesta.error) {
            throw respuesta.error;
          }
          return response;
        }),
        catchError(this.handleError)
      );
  }
  /**
   * Obtiene el reporte de asistencia por rango de fechas
   */
  obtenerReportePorFecha(filtros: { fecha_inicio?: string; fecha_fin?: string; fecha?: string }) {
    return this.http.post<any>(this.servicio + '/reporte-por-fecha', filtros, httpOptions).pipe(
      tap((respuesta: any) => {
        if (respuesta.error) throw respuesta.error;
        return respuesta;
      }),
      catchError(this.handleError)
    );
  }

  /**
   * Obtiene el reporte de indicadores de asistencia de todos los estudiantes
   * @param fecha - Fecha de referencia para los cálculos (opcional, por defecto hoy)
   */
  obtenerReporteIndicadores(fecha?: string) {
    const fechaReferencia = fecha || new Date().toISOString().split('T')[0];
    const url = `${this.servicio}-reporte-indicadores?fecha=${fechaReferencia}`;

    return this.http
      .get<any>(url)
      .pipe(
        tap((respuesta: any) => {
          if (respuesta.error) {
            throw respuesta.error;
          }
          return respuesta;
        }),
        catchError(this.handleError)
      );
  }
    // Método simple para obtener estudiantes que asistieron en una fecha específica
  obtenerEstudiantesPorFecha(fecha: string) {
    return this.http
      .get<any>(`${environment.api}asistencia-estudiantes-fecha/${fecha}`)
      .pipe(
        tap((respuesta: any) => {
          if (respuesta.error) throw respuesta.error;
          return respuesta;
        }),
        catchError(this.handleError)
      );
  }

  /**
   * Obtiene datos de seguimiento de asistencia + acudientes en una sola llamada.
   */
  obtenerSeguimientoAsistencia(fecha?: string) {
    const fechaReferencia = fecha || new Date().toISOString().split('T')[0];
    const url = `${environment.api}seguimiento-asistencia-estudiantes?fecha=${fechaReferencia}`;

    return this.http
      .get<any>(url)
      .pipe(
        tap((respuesta: any) => {
          if (respuesta.error) {
            throw respuesta.error;
          }
          return respuesta;
        }),
        catchError(this.handleError)
      );
  }

  /**
   * Personas que pueden traer (ingreso) o recoger (salida) al nino en la
   * fecha, con la ultima eleccion en id_persona_sugerida.
   */
  obtenerPersonasEntregaRecoge(idEstudiante: string, tipo: string, fecha: string) {
    const params = new HttpParams()
      .set('tipo', tipo)
      .set('fecha', fecha);

    return this.http
      .get<any>(`${this.servicio}/personas-entrega/${idEstudiante}`, { params })
      .pipe(
        tap((respuesta: any) => {
          if (respuesta.error) throw respuesta.error;
          return respuesta;
        }),
        catchError(this.handleError)
      );
  }

  private handleError(error: HttpErrorResponse) {
    return throwError(() => error);
  }
}