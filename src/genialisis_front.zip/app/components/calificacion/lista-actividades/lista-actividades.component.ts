import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from '../../../common/header/header.component';
import { EditorTextoEnriquecidoComponent } from '../../../common/editor-texto-enriquecido/editor-texto-enriquecido.component';
import { SearchPipeGeneral } from '../../../common/pipes/search';
import { normalizarTexto } from '../../../common/pipes/search';
import { ActividadesAcademicasService } from '../../../services/actividades-academicas.service';
import { AreasAcademicasService } from '../../../services/areas-academicas.service';
import { GruposService } from '../../../services/grupos.service';
import { CursosExtraService } from '../../../services/cursos-extra.service';
import { AmbientesService } from '../../../services/ambientes.service';
import { TiposActividadesAcademicasService } from '../../../services/tipos-actividades-academicas.service';
import { IaMaquinaActividadesService } from '../../../services/ia-maquina-actividades.service';
import { SprintsService } from '../../../services/sprints.service';
import { TareasXSprintsService } from '../../../services/tareas-x-sprints.service';
import { LogrosService } from '../../../services/logros.service';
import { CalificacionContextService } from '../../../services/calificacion-context.service';
import { PermisosService } from '../../../services/permisos.service';
import { UtilService } from '../../../common/constantes/util.service';
import collect from 'collect.js';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-lista-actividades',
  templateUrl: './lista-actividades.component.html',
  styleUrl: './lista-actividades.component.scss',
  standalone: true,
  imports: [CommonModule, FormsModule, HeaderComponent, SearchPipeGeneral, EditorTextoEnriquecidoComponent]
})
export class ListaActividadesComponent implements OnInit {

  public titulo = "Registro de calificaciones";
  public grupo: any = null;
  public area: any = null;
  public actividadesPendientes: any[] = [];

  // Actividades ya ejecutadas o canceladas. Solo se listan si el usuario tiene
  // el permiso para devolverlas a Pendiente.
  public actividadesFinalizadas: any[] = [];
  public verFinalizadas: boolean = false;
  public buscarFinalizadas: string = '';
  public cambiandoEstado: any = null;

  // Estado al que se devuelve una actividad reabierta (estados_tareas: 1 Pendiente)
  private readonly idEstadoPendiente: number = 1;
  public siguienteActividad: any = null;
  public verTodas: boolean = false;
  public buscar: string = '';

  // Modo edición (orden + duración)
  public modoEdicion: boolean = false;
  public guardandoOrden: boolean = false;
  public dragIndex: number = -1;
  public buscarEdicion: string = '';

  // Crear actividad rápida
  public mostrarFormCrear: boolean = false;
  public ambientes: any[] = [];
  public tiposActividad: any[] = [];
  public sprintActual: any = null;
  public logrosDisponibles: any[] = [];
  public logrosCargados: boolean = false;
  public sugiriendoIA: boolean = false;
  public busquedaIndicadorForm: string = '';
  public intentoCrear: boolean = false;

  // Tab del panel: crear una actividad nueva o importar una del corte
  public tabCrear: 'crear' | 'importar' = 'crear';
  public actividadesImportables: any[] = [];
  public importablesCargados: boolean = false;
  public cargandoImportables: boolean = false;
  public buscarImportar: string = '';
  public importableSeleccionada: any = null;
  public importableExpandida: any = null;
  public importando: boolean = false;

  public formActividad = {
    titulo: '',
    descripcion: '',
    nivel_uno: '',
    nivel_dos: '',
    minutos_duracion: 45,
    id_tipo_actividad_academica: '' as any,
    id_ambiente: null as any,
    indicadores_ids: [] as string[],
    indicadores: [] as any[]
  };

  public idGrupo: string = '';
  public idArea: string = '';
  /* Id del curso extracurricular cuando la pantalla se abre por esa ruta. */
  public idCursoExtra: string = '';

  // Touch drag state
  private touchStartY: number = 0;
  private touchCurrentElement: HTMLElement | null = null;
  private placeholder: HTMLElement | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private actividadesAcademicasService: ActividadesAcademicasService,
    private areasAcademicasService: AreasAcademicasService,
    private gruposService: GruposService,
    private cursosExtraService: CursosExtraService,
    private ambientesService: AmbientesService,
    private tiposActividadesService: TiposActividadesAcademicasService,
    private iaMaquinaService: IaMaquinaActividadesService,
    private sprintsService: SprintsService,
    private tareasXSprintsService: TareasXSprintsService,
    private logrosService: LogrosService,
    private calificacionContext: CalificacionContextService,
    public permisosService: PermisosService,
    private utilService: UtilService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.idGrupo = params['idGrupo'];
      this.idArea = params['idArea'];
      // Cuando la pantalla se abre para un curso extracurricular, el curso
      // ocupa el lugar del grupo y el área sale del propio curso.
      this.idCursoExtra = params['idCursoExtra'] || '';
      this.cargarDatosIniciales();
    });
  }

  private cargarDatosIniciales(): void {
    if (this.idCursoExtra) {
      this.cargarDatosCursoExtra();
    } else {
      this.gruposService.obtenerTodos().subscribe((resp: any) => {
        const grupos = resp.body || [];
        this.grupo = grupos.find((g: any) => g.id == this.idGrupo) || null;
      });

      this.areasAcademicasService.obtenerAreasAcademicasGrupo(this.idGrupo)
        .subscribe((resp: any) => {
          const areas = resp.body || [];
          this.area = areas.find((a: any) => a.id_area_academica == this.idArea) || null;
        });
    }

    this.cargarActividades();
    this.cargarCatalogosCrear();
  }

  /**
   * El curso hace las veces de grupo en el encabezado, y su área académica es
   * la materia de la que salen los logros.
   */
  private cargarDatosCursoExtra(): void {
    this.cursosExtraService.obtenerById(this.idCursoExtra).subscribe((resp: any) => {
      const body = resp.body || [];
      const curso = body.length > 0 ? body[0] : null;
      if (!curso) {
        return;
      }

      // Se reusa `grupo` para que el encabezado y el resto de la pantalla no
      // tengan que distinguir de qué tipo de destino se trata.
      this.grupo = {
        id: curso.id,
        nombre: curso.nombre,
        color: curso.color,
        icono: curso.icono
      };
      this.idArea = curso.id_area_academica;
      this.area = {
        id_area_academica: curso.id_area_academica,
        nombre: curso.nombre_area_academica
      };
    });
  }

  private cargarActividades(): void {
    // Las clases de un curso no tienen grupo ni área en la ruta: se piden por curso.
    const peticion = this.idCursoExtra
      ? this.actividadesAcademicasService.obtenerByCursoExtra(this.idCursoExtra)
      : this.actividadesAcademicasService.obtenerByGrupoArea(this.idGrupo, this.idArea);

    peticion
      .subscribe((response: any) => {
        const todas = (response.body || []).map((actividad: any) => ({
          ...actividad,
          titulo: this.limpiarHTML(actividad.titulo),
          descripcion: this.limpiarHTML(actividad.descripcion),
          materiales: this.limpiarHTML(actividad.materiales),
          nivel_uno: this.limpiarHTML(actividad.nivel_uno),
          nivel_dos: this.limpiarHTML(actividad.nivel_dos),
          indicador_logro_nombre: this.limpiarHTML(actividad.indicador_logro_nombre)
        }));

        const actividades = collect(todas)
          .where("nombre_estado", "Pendiente")
          .all();

        // Todo lo que no está pendiente se guarda aparte, para poder
        // consultarlo y devolverlo a Pendiente si se tiene el permiso.
        this.actividadesFinalizadas = collect(todas)
          .filter((actividad: any) => actividad.nombre_estado !== 'Pendiente')
          .all() as any[];

        this.actividadesPendientes = actividades;
        this.siguienteActividad = actividades.length > 0 ? actividades[0] : null;
      });
  }

  private limpiarHTML(html: string): string {
    if (!html) return '';
    let cleanHtml = html
      .replace(/ style="[^"]*"/gi, '')
      .replace(/ class="[^"]*"/gi, '')
      .replace(/<font[^>]*>/gi, '')
      .replace(/<\/font>/gi, '')
      .replace(/<span[^>]*>/gi, '')
      .replace(/<\/span>/gi, '')
      .replace(/&nbsp;/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    cleanHtml = cleanHtml.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    cleanHtml = cleanHtml.replace(/__(.*?)__/g, '<em>$1</em>');
    return cleanHtml;
  }

  private cargarCatalogosCrear(): void {
    this.ambientesService.obtenerActivos().subscribe((resp: any) => {
      this.ambientes = resp.body || [];
    });
    this.tiposActividadesService.obtenerTodos().subscribe((resp: any) => {
      this.tiposActividad = resp.body || [];
    });
    this.sprintsService.obtenerTodos().subscribe((resp: any) => {
      const sprints = resp.body || [];
      this.sprintActual = sprints.find((s: any) => s.actual == 1) || null;
    });
  }

  seleccionarActividad(actividad: any): void {
    if (this.modoEdicion) return;
    this.router.navigate(this.rutaCalificar(actividad.id_tarea_x_sprint));
  }

  /** Ruta de la pantalla de calificar, según el destino. */
  private rutaCalificar(idTareaSprint: any): any[] {
    if (this.idCursoExtra) {
      return ['/calificacion/curso-extra', this.idCursoExtra, 'actividad', idTareaSprint];
    }
    return ['/calificacion/grupo', this.idGrupo, 'area', this.idArea, 'actividad', idTareaSprint];
  }

  toggleVerTodas(): void {
    this.verTodas = !this.verTodas;
  }

  // ========================================================================
  // ACTIVIDADES FINALIZADAS: consulta y regreso a Pendiente
  // ========================================================================

  /** El bloque de finalizadas solo existe si hay permiso y hay algo que mostrar */
  get puedeVerFinalizadas(): boolean {
    return this.permisosService.tienePermiso('calificaciones.reabrir_actividad')
      && this.actividadesFinalizadas.length > 0;
  }

  toggleVerFinalizadas(): void {
    this.verFinalizadas = !this.verFinalizadas;
  }

  /**
   * Devuelve una actividad finalizada al estado Pendiente para poder
   * volver a calificarla. Pide confirmación porque afecta el registro.
   */
  reabrirActividad(actividad: any): void {
    if (!this.permisosService.tienePermiso('calificaciones.reabrir_actividad')) return;
    if (this.cambiandoEstado) return;

    Swal.fire({
      title: '¿Reabrir la actividad?',
      html: `La actividad pasará de <b>${actividad.nombre_estado}</b> a <b>Pendiente</b> y volverá al listado para calificarla.`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonColor: '#F5A623',
      cancelButtonColor: '#2C2C2C',
      confirmButtonText: 'Sí, reabrir',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      if (!result.isConfirmed) return;

      this.cambiandoEstado = actividad.id_tarea_x_sprint;

      this.tareasXSprintsService.actualizarEstado({
        id: actividad.id_tarea_x_sprint,
        id_estado_tarea: this.idEstadoPendiente
      }).subscribe({
        next: () => {
          this.cambiandoEstado = null;
          Swal.fire({
            title: 'Actividad reabierta',
            text: 'Ya puedes calificarla de nuevo.',
            icon: 'success',
            confirmButtonColor: '#F5A623'
          });
          this.cargarActividades();
        },
        error: (error: any) => {
          this.cambiandoEstado = null;
          console.error('Error al reabrir la actividad', error);
          Swal.fire('Error', 'No se pudo cambiar el estado de la actividad.', 'error');
        }
      });
    });
  }

  // ========================================================================
  // MODO EDICIÓN: Orden + Duración
  // ========================================================================

  activarModoEdicion(): void {
    this.verTodas = true;
    this.modoEdicion = true;
    this.buscarEdicion = '';
  }

  cancelarModoEdicion(): void {
    this.modoEdicion = false;
    this.buscarEdicion = '';
    this.cargarActividades();
  }

  guardarOrdenYDuracion(): void {
    this.guardandoOrden = true;

    const tareas = this.actividadesPendientes.map((a: any, i: number) => ({
      id: a.id_tarea_x_sprint,
      orden_ejecucion: i + 1,
      id_actividad_academica: a.id_actividad_academica,
      minutos_duracion: a.minutos_duracion
    }));

    this.tareasXSprintsService.actualizarOrdenYDuracion(tareas).subscribe({
      next: (resp: any) => {
        this.guardandoOrden = false;
        this.modoEdicion = false;
        Swal.fire({ toast: true, position: 'top-end', icon: 'success', title: 'Orden y duración guardados', showConfirmButton: false, timer: 1500 });
        this.cargarActividades();
      },
      error: () => {
        this.guardandoOrden = false;
        Swal.fire('Error', 'No se pudo guardar el orden.', 'error');
      }
    });
  }

  // Mover con botones (alternativa al drag)
  moverArriba(index: number): void {
    if (index <= 0) return;
    const temp = this.actividadesPendientes[index];
    this.actividadesPendientes[index] = this.actividadesPendientes[index - 1];
    this.actividadesPendientes[index - 1] = temp;
  }

  moverAbajo(index: number): void {
    if (index >= this.actividadesPendientes.length - 1) return;
    const temp = this.actividadesPendientes[index];
    this.actividadesPendientes[index] = this.actividadesPendientes[index + 1];
    this.actividadesPendientes[index + 1] = temp;
  }

  moverAlInicio(index: number): void {
    if (index <= 0) return;
    const item = this.actividadesPendientes.splice(index, 1)[0];
    this.actividadesPendientes.unshift(item);
  }

  moverAlFinal(index: number): void {
    if (index >= this.actividadesPendientes.length - 1) return;
    const item = this.actividadesPendientes.splice(index, 1)[0];
    this.actividadesPendientes.push(item);
  }

  coincideBusquedaEdicion(actividad: any): boolean {
    if (!this.buscarEdicion || !this.buscarEdicion.trim()) return true;
    const texto = (actividad.titulo || '').toLowerCase();
    return texto.includes(this.buscarEdicion.toLowerCase().trim());
  }

  // Touch Drag & Drop
  onTouchStart(event: TouchEvent, index: number): void {
    this.dragIndex = index;
    this.touchStartY = event.touches[0].clientY;
    this.touchCurrentElement = event.currentTarget as HTMLElement;
    this.touchCurrentElement.classList.add('dragging');
  }

  onTouchMove(event: TouchEvent): void {
    if (this.dragIndex < 0 || !this.touchCurrentElement) return;
    event.preventDefault();

    const touchY = event.touches[0].clientY;
    const container = this.touchCurrentElement.parentElement;
    if (!container) return;

    const items = Array.from(container.querySelectorAll('.ficha-edicion'));
    const currentRect = this.touchCurrentElement.getBoundingClientRect();
    const deltaY = touchY - (currentRect.top + currentRect.height / 2);

    // Determinar si se debe intercambiar
    for (let i = 0; i < items.length; i++) {
      if (i === this.dragIndex) continue;
      const rect = (items[i] as HTMLElement).getBoundingClientRect();
      const midY = rect.top + rect.height / 2;

      if (touchY < midY && i < this.dragIndex) {
        this.reordenar(this.dragIndex, i);
        this.dragIndex = i;
        break;
      } else if (touchY > midY && i > this.dragIndex) {
        this.reordenar(this.dragIndex, i);
        this.dragIndex = i;
        break;
      }
    }
  }

  onTouchEnd(event: TouchEvent): void {
    if (this.touchCurrentElement) {
      this.touchCurrentElement.classList.remove('dragging');
    }
    this.dragIndex = -1;
    this.touchCurrentElement = null;
  }

  // HTML5 Drag (desktop)
  onDragStart(event: DragEvent, index: number): void {
    this.dragIndex = index;
    if (event.dataTransfer) {
      event.dataTransfer.effectAllowed = 'move';
    }
  }

  onDragOver(event: DragEvent, index: number): void {
    event.preventDefault();
    if (this.dragIndex < 0 || this.dragIndex === index) return;
    this.reordenar(this.dragIndex, index);
    this.dragIndex = index;
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    this.dragIndex = -1;
  }

  onDragEnd(): void {
    this.dragIndex = -1;
  }

  private reordenar(from: number, to: number): void {
    const item = this.actividadesPendientes.splice(from, 1)[0];
    this.actividadesPendientes.splice(to, 0, item);
  }

  // ========================================================================
  // CREAR ACTIVIDAD RÁPIDA
  // ========================================================================

  abrirFormCrear(): void {
    if (!this.sprintActual) {
      Swal.fire('Sin sprint', 'No hay un sprint actual configurado.', 'warning');
      return;
    }
    this.limpiarFormActividad();
    this.limpiarImportar();
    this.tabCrear = 'crear';
    this.mostrarFormCrear = true;
    this.cargarLogrosParaCrear();
  }

  cerrarFormCrear(): void {
    this.mostrarFormCrear = false;
  }

  private limpiarFormActividad(): void {
    this.intentoCrear = false;
    const bloque = this.calificacionContext.getBloqueActual(this.idGrupo, this.idArea);
    const minutosDefault = bloque ? parseInt(bloque.total_minutos) || 45 : 45;
    this.formActividad = {
      titulo: '',
      descripcion: '',
      nivel_uno: '',
      nivel_dos: '',
      minutos_duracion: minutosDefault,
      id_tipo_actividad_academica: '',
      id_ambiente: null,
      indicadores_ids: [],
      indicadores: []
    };
    this.busquedaIndicadorForm = '';
  }

  private cargarLogrosParaCrear(): void {
    this.logrosCargados = false;
    if (!this.grupo || !this.area) return;

    // En un curso extracurricular los logros van por nivel y no por grado, y
    // no hay grupo contra el cual filtrar: se traen todos los del área.
    const peticion = this.idCursoExtra
      ? this.logrosService.obtenerByAreaConIndicadores(this.area.id_area_academica)
      : this.logrosService.obtenerByGrupoAreaConIndicadores(this.grupo.id, this.area.id_area_academica);

    peticion
      .subscribe({
        next: (resp: any) => {
          this.logrosDisponibles = resp.body || [];
          this.logrosCargados = true;
        },
        error: () => {
          this.logrosDisponibles = [];
          this.logrosCargados = true;
        }
      });
  }

  /**
   * Ids de todos los indicadores realmente existentes para el grupo y área actuales.
   * Sirve como filtro contra ids inventados por la IA.
   */
  private idsIndicadoresDisponibles(): string[] {
    const ids: string[] = [];
    for (const logro of this.logrosDisponibles) {
      for (const ind of (logro.indicadores || [])) {
        ids.push(ind.id);
      }
    }
    return ids;
  }

  /** El área está cargada y no tiene ningún logro asociado. */
  areaSinLogros(): boolean {
    return this.logrosCargados && this.logrosDisponibles.length === 0;
  }

  formActividadValido(): boolean {
    return !!(this.formActividad.titulo.trim() && this.formActividad.id_tipo_actividad_academica);
  }

  formRequiereIndicador(): boolean {
    return this.logrosDisponibles.length > 0 && this.formActividad.indicadores_ids.length === 0;
  }

  /** Texto sin etiquetas: el editor enriquecido deja "<p></p>" cuando está vacío. */
  private textoPlano(html: string): string {
    return (html || '').replace(/<[^>]*>/g, ' ').replace(/&nbsp;/gi, ' ').replace(/\s+/g, ' ').trim();
  }

  /** La IA necesita al menos el título o la descripción como idea base. */
  tieneIdeaBase(): boolean {
    return !!(this.formActividad.titulo.trim() || this.textoPlano(this.formActividad.descripcion));
  }

  async sugerirConIA(): Promise<void> {
    if (!this.tieneIdeaBase()) {
      Swal.fire('Escribe la idea', 'Escribe el título o la descripción para sugerir.', 'info');
      return;
    }

    // Reescribir: la IA redacta título y descripción a partir de lo escrito.
    // Conservar: se respeta lo escrito y solo se llena lo vacío.
    const eleccion = await Swal.fire({
      title: '🪄 Sugerir con IA',
      text: '¿La IA reescribe el título y la descripción a partir de lo que escribiste, o conservas tu texto y solo completa lo vacío?',
      icon: 'question',
      showDenyButton: true,
      showCancelButton: true,
      confirmButtonColor: '#F5A623',
      denyButtonColor: '#6c757d',
      cancelButtonColor: '#2C2C2C',
      confirmButtonText: 'Reescribir',
      denyButtonText: 'Conservar lo que escribí',
      cancelButtonText: 'Cancelar'
    });
    if (eleccion.isDismissed) return;
    const reescribir = eleccion.isConfirmed;

    this.sugiriendoIA = true;

    // En un curso extracurricular el destino es el curso, no un grupo: el back
    // resuelve los logros por área en lugar de por el grado del grupo.
    const datos = {
      modo: reescribir ? 'reescribir' : 'completar',
      titulo: this.formActividad.titulo,
      descripcion: this.formActividad.descripcion,
      nivel_uno: this.formActividad.nivel_uno,
      nivel_dos: this.formActividad.nivel_dos,
      id_grupo: this.idCursoExtra ? null : this.grupo.id,
      id_curso_extra: this.idCursoExtra || null,
      id_area: this.area.id_area_academica,
      id_sprint: this.sprintActual.id,
      nombre_grupo: this.grupo.nombre,
      // El área del curso se arma con la llave `nombre`; la de la malla regular
      // viene con `nombre_area_academica`.
      nombre_area: this.area.nombre_area_academica || this.area.nombre,
      id_tipo_actividad: this.formActividad.id_tipo_actividad_academica,
      ambientes: this.ambientes.map((a: any) => ({ id: a.id, nombre: a.nombre })),
      materiales: []
    };

    this.iaMaquinaService.sugerirIndividual(datos).subscribe({
      next: (resp: any) => {
        this.sugiriendoIA = false;
        if (resp.success && resp.sugerencia) {
          const s = resp.sugerencia;
          // Título y descripción: al reescribir se reemplazan; al conservar solo se llenan si están vacíos
          if (s.titulo && (reescribir || !this.formActividad.titulo.trim())) this.formActividad.titulo = s.titulo;
          if (s.descripcion && (reescribir || !this.textoPlano(this.formActividad.descripcion))) this.formActividad.descripcion = s.descripcion;
          if (!this.formActividad.nivel_uno && s.nivel_uno) this.formActividad.nivel_uno = s.nivel_uno;
          if (!this.formActividad.nivel_dos && s.nivel_dos) this.formActividad.nivel_dos = s.nivel_dos;
          if (s.minutos_duracion && this.formActividad.minutos_duracion === 45) this.formActividad.minutos_duracion = s.minutos_duracion;
          if (s.id_ambiente && !this.formActividad.id_ambiente) this.formActividad.id_ambiente = s.id_ambiente;
          if (s.id_tipo_actividad_academica && !this.formActividad.id_tipo_actividad_academica) {
            this.formActividad.id_tipo_actividad_academica = s.id_tipo_actividad_academica;
          }
          if (s.indicadores_ids && this.formActividad.indicadores_ids.length === 0) {
            // Solo se aceptan indicadores que existan en los logros cargados desde la BD.
            const disponibles = this.idsIndicadoresDisponibles();
            this.formActividad.indicadores_ids = (s.indicadores_ids as string[])
              .filter((id: string) => disponibles.includes(id));
            this.formActividad.indicadores = (s.indicadores || [])
              .filter((ind: any) => this.formActividad.indicadores_ids.includes(ind.id));
          }
          Swal.fire({ title: reescribir ? '🪄 Actividad redactada' : '🪄 Sugerencias aplicadas', icon: 'success', timer: 1500, showConfirmButton: false });
        }
      },
      error: () => {
        this.sugiriendoIA = false;
        Swal.fire('Error', 'No se pudo obtener la sugerencia.', 'error');
      }
    });
  }

  toggleIndicadorForm(indicadorId: string): void {
    const idx = this.formActividad.indicadores_ids.indexOf(indicadorId);
    if (idx >= 0) {
      this.formActividad.indicadores_ids.splice(idx, 1);
      this.formActividad.indicadores = this.formActividad.indicadores.filter((ind: any) => ind.id !== indicadorId);
    } else {
      for (const logro of this.logrosDisponibles) {
        for (const ind of logro.indicadores) {
          if (ind.id === indicadorId) {
            this.formActividad.indicadores_ids.push(indicadorId);
            this.formActividad.indicadores.push({ id: ind.id, nombre: ind.nombre, logro_id: logro.id, logro_nombre: logro.nombre });
            return;
          }
        }
      }
    }
  }

  quitarIndicadorForm(indId: string): void {
    this.formActividad.indicadores_ids = this.formActividad.indicadores_ids.filter((id: string) => id !== indId);
    this.formActividad.indicadores = this.formActividad.indicadores.filter((ind: any) => ind.id !== indId);
  }

  indicadorFormCoincideBusqueda(ind: any): boolean {
    const busqueda = normalizarTexto(this.busquedaIndicadorForm).trim();
    if (!busqueda) return true;
    return normalizarTexto(ind.nombre).includes(busqueda);
  }

  tieneIndicadoresFormFiltrados(logro: any): boolean {
    return logro.indicadores.some((ind: any) => this.indicadorFormCoincideBusqueda(ind));
  }

  crearYCalificar(): void {
    this.intentoCrear = true;
    if (!this.formActividadValido()) {
      Swal.fire('Campos obligatorios', 'Completa el título y selecciona el tipo de actividad.', 'warning');
      return;
    }
    if (this.formRequiereIndicador()) {
      Swal.fire('Indicador requerido', 'Debes asociar al menos un indicador de logro.', 'warning');
      return;
    }

    Swal.fire({
      title: 'Creando actividad...',
      allowOutsideClick: false,
      didOpen: () => { Swal.showLoading(); }
    });

    // La clase de un curso extracurricular se graba contra el curso y no contra
    // un grupo: el back deja id_grupo nulo cuando llega id_curso_extra.
    const payload = {
      id_sprint: this.sprintActual.id,
      id_grupo: this.idCursoExtra ? null : this.grupo.id,
      id_curso_extra: this.idCursoExtra || null,
      id_area: this.area.id_area_academica,
      es_tarea_adicional: true,
      actividades: [{
        titulo: this.formActividad.titulo,
        descripcion: this.formActividad.descripcion,
        nivel_uno: this.formActividad.nivel_uno,
        nivel_dos: this.formActividad.nivel_dos,
        minutos_duracion: this.formActividad.minutos_duracion,
        id_tipo_actividad_academica: this.formActividad.id_tipo_actividad_academica || null,
        id_ambiente: this.formActividad.id_ambiente ? this.formActividad.id_ambiente : null,
        indicadores_ids: this.formActividad.indicadores_ids,
        materiales: []
      }]
    };

    this.iaMaquinaService.grabarActividades(payload).subscribe({
      next: (resp: any) => {
        if (resp.success && resp.actividades?.length > 0) {
          Swal.close();
          this.mostrarFormCrear = false;
          const actividadCreada = resp.actividades[0];
          const idTarea = actividadCreada.id_tarea_sprint;
          if (idTarea) {
            this.router.navigate(this.rutaCalificar(idTarea));
          }
        } else {
          Swal.fire('Error', resp.error || 'No se pudo crear.', 'error');
        }
      },
      error: (err: any) => {
        const mensaje = err?.error?.error || 'No se pudo crear la actividad.';
        Swal.fire('Error', mensaje, 'error');
      }
    });
  }

  // ========================================================================
  // IMPORTAR ACTIVIDAD DEL CORTE
  // ========================================================================

  cambiarTabCrear(tab: 'crear' | 'importar'): void {
    this.tabCrear = tab;
    if (tab === 'importar' && !this.importablesCargados) {
      this.cargarImportables();
    }
  }

  private limpiarImportar(): void {
    this.actividadesImportables = [];
    this.importablesCargados = false;
    this.buscarImportar = '';
    this.importableSeleccionada = null;
    this.importableExpandida = null;
  }

  /**
   * Actividades del mismo grupo y área (o curso) en los sprints del corte del
   * sprint actual, menos las que ya están pendientes en el sprint actual.
   */
  private cargarImportables(): void {
    if (!this.sprintActual || !this.grupo || !this.area) return;
    this.cargandoImportables = true;

    this.tareasXSprintsService.obtenerParaImportarCorte(
      this.sprintActual.id,
      this.idCursoExtra ? null : this.grupo.id,
      this.idCursoExtra ? null : this.area.id_area_academica,
      this.idCursoExtra || null
    ).subscribe({
      next: (resp: any) => {
        this.actividadesImportables = (resp.body || []).map((act: any) => ({
          ...act,
          titulo_actividad: this.limpiarHTML(act.titulo_actividad),
          descripcion_actividad: this.limpiarHTML(act.descripcion_actividad)
        }));
        this.importablesCargados = true;
        this.cargandoImportables = false;
      },
      error: () => {
        this.actividadesImportables = [];
        this.importablesCargados = true;
        this.cargandoImportables = false;
      }
    });
  }

  get importablesVisibles(): any[] {
    const busqueda = normalizarTexto(this.buscarImportar).trim();
    if (!busqueda) return this.actividadesImportables;
    return this.actividadesImportables.filter((act: any) =>
      normalizarTexto(act.titulo_actividad).includes(busqueda) ||
      normalizarTexto((act.descripcion_actividad || '').replace(/<[^>]*>/g, ' ')).includes(busqueda)
    );
  }

  seleccionarImportable(act: any): void {
    this.importableSeleccionada = this.importableSeleccionada === act ? null : act;
  }

  toggleDescripcionImportable(act: any, event: Event): void {
    event.stopPropagation();
    this.importableExpandida = this.importableExpandida === act ? null : act;
  }

  /**
   * Crea la tarea en el sprint actual con la misma actividad (conserva sus
   * indicadores), marcada como adicional, y abre la calificación.
   */
  importarYCalificar(): void {
    if (!this.importableSeleccionada || this.importando) return;
    this.importando = true;

    Swal.fire({
      title: 'Importando actividad...',
      allowOutsideClick: false,
      didOpen: () => { Swal.showLoading(); }
    });

    this.tareasXSprintsService.crearLote({
      id_sprint: this.sprintActual.id,
      actividades: [this.importableSeleccionada.id_actividad_academica],
      id_grupo: this.idCursoExtra ? null : this.grupo.id,
      id_area_academica: this.area.id_area_academica,
      id_curso_extra: this.idCursoExtra || null,
      es_tarea_adicional: 1
    }).subscribe({
      next: (resp: any) => {
        this.importando = false;
        const idTarea = resp?.tareas?.length > 0 ? resp.tareas[0].id : null;
        if (!idTarea) {
          Swal.fire('Error', resp?.omitidas?.[0]?.motivo || resp?.error || 'No se pudo importar la actividad.', 'error');
          return;
        }
        Swal.close();
        this.mostrarFormCrear = false;
        this.router.navigate(this.rutaCalificar(idTarea));
      },
      error: (err: any) => {
        this.importando = false;
        const mensaje = err?.error?.error || 'No se pudo importar la actividad.';
        Swal.fire('Error', mensaje, 'error');
      }
    });
  }

  getNombreAmbiente(id: any): string {
    const amb = this.ambientes.find((a: any) => a.id == id);
    return amb?.nombre || '';
  }

  getIconoAmbiente(id: any): string {
    const amb = this.ambientes.find((a: any) => a.id == id);
    return amb?.icono || '📍';
  }
}