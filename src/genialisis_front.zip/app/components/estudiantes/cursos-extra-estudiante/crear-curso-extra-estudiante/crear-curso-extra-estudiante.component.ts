import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from '../../../../common/header/header.component';
import { FechaInputComponent } from '../../../../common/fecha-input/fecha-input.component';
import { UtilService } from '../../../../common/constantes/util.service';
import { CursosExtraService } from '../../../../services/cursos-extra.service';
import { EstudiantesXCursosExtraService } from '../../../../services/estudiantes-x-cursos-extra.service';
import { TarifasCursosExtraService } from '../../../../services/tarifas-cursos-extra.service';
import { CursosExtraXInstitucionesClienteService } from '../../../../services/cursos-extra-x-instituciones-cliente.service';
import { EstudiantesService } from '../../../../services/estudiantes.service';
import { CuentasPorCobrarService } from '../../../../services/cuentas-por-cobrar.service';
import { InstitucionConfigService } from '../../../../services/institucion-config.service';
import Swal from 'sweetalert2';

interface ValorGenerado {
  id_producto_servicio: string;
  nombre_producto: string;
  fecha: string;
  valor: number;
  tipo: string;
  detalle: string;
  // Valor de la tarifa de esa cuota y por qué se cobra menos. Se guardan en
  // la cuenta como foto del momento.
  valor_base: number | null;
  motivo_descuento: string;
}

@Component({
  selector: 'app-crear-curso-extra-estudiante',
  standalone: true,
  imports: [HeaderComponent, CommonModule, FormsModule, FechaInputComponent],
  templateUrl: './crear-curso-extra-estudiante.component.html',
  styleUrl: './crear-curso-extra-estudiante.component.scss'
})
export class CrearCursoExtraEstudianteComponent implements OnInit {

  public idEstudiante = "0";
  public idInscripcion: any = null;
  public accion = "";
  public editable = true;
  public submitted = false;
  public guardando = false;
  public generandoCuentas = false;
  public titulo = "Inscribir a Curso Extracurricular";
  public regresar = '/estudiantes/cursos-extra';

  public estudiante: any;
  public nombre_estudiante = "";
  public cursosDisponibles: any[] = [];
  public tarifa: any = null;
  public cursoSeleccionado: any = null;

  // Convenios del curso. Si el curso no tiene, el selector no se muestra y la
  // inscripcion es particular, que es como funcionaba antes.
  public conveniosCurso: any[] = [];

  public model = {
    id_curso_extra: null,
    // Convenio por el que entra el estudiante. Null = particular. Decide la
    // tarifa y a nombre de quien se emite la cuenta.
    id_institucion_cliente: null,
    fecha_inicio: '',
    fecha_fin: '',
    // Fecha con la que se registra la inscripcion. Arranca en hoy, es editable, y
    // es el punto de partida del calculo de las cuotas.
    fecha_inscripcion: '',
  } as any;

  /* Filas del detalle de la tarifa que se cobran siempre (matrícula, pensión
     y cobro único), copiadas para que el valor y las cuotas se puedan ajustar
     en esta inscripción sin tocar la tarifa. */
  public lineasFijas: any[] = [];

  /* Paquetes de sesiones de la tarifa. Se compra uno solo por inscripción:
     el que escoja el acudiente. */
  public paquetes: any[] = [];
  public idPaqueteSeleccionado: any = null;
  public valorPaquete: number = 0;
  // Por qué se cobra el paquete por menos de lo que vale en la tarifa
  public motivoPaquete: string = '';

  // Valores editables de tarifa
  public valorMatricula: number = 0;
  public valorMatriculaFormateado: string = '';
  public cuotasMatricula: number = 1;
  public valorPension: number = 0;
  public valorPensionFormateado: string = '';
  public valorUnico: number = 0;
  public valorUnicoFormateado: string = '';
  public cuotasUnico: number = 1;

  // Valores generados
  public valoresGenerados: boolean = false;
  public valores: ValorGenerado[] = [];
  public resumen = {
    total_matricula: 0,
    total_pension: 0,
    total_unico: 0,
    total_paquete: 0,
    total_general: 0,
    cuentas: 0
  };

  nombresMeses: any = {
    1: 'Enero', 2: 'Febrero', 3: 'Marzo', 4: 'Abril',
    5: 'Mayo', 6: 'Junio', 7: 'Julio', 8: 'Agosto',
    9: 'Septiembre', 10: 'Octubre', 11: 'Noviembre', 12: 'Diciembre'
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private cursosExtraService: CursosExtraService,
    private estudiantesXCursosExtraService: EstudiantesXCursosExtraService,
    private tarifasCursosExtraService: TarifasCursosExtraService,
    private cursosExtraXInstitucionesClienteService: CursosExtraXInstitucionesClienteService,
    private estudiantesService: EstudiantesService,
    private cuentasPorCobrarService: CuentasPorCobrarService,
    private institucionConfigService: InstitucionConfigService,
    private utilService: UtilService,
  ) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.accion = params['accion'];
      this.idEstudiante = params['idEstudiante'];
      this.regresar = '/estudiantes/cursos-extra/' + this.idEstudiante;

      if (this.accion === 'crear') {
        this.titulo = "Inscribir a Curso Extracurricular";
        this.editable = true;
      }

      this.model.fecha_inscripcion = this.formatearFechaISO(new Date());

      this.obtenerEstudiante(this.idEstudiante);
      this.cargarCursosDisponibles();
    });
  }

  obtenerEstudiante(id_estudiante: any) {
    this.estudiantesService.obtenerById(id_estudiante).subscribe((response: any) => {
      const body = response.body as any[];
      this.estudiante = body[0];
      this.nombre_estudiante = [
        this.estudiante.primer_nombre,
        this.estudiante.segundo_nombre,
        this.estudiante.primer_apellido,
        this.estudiante.segundo_apellido
      ].filter(Boolean).join(' ');
      if (this.accion === 'crear') {
        this.titulo = "Inscribir a " + this.nombre_estudiante;
      }
    });
  }

  cargarCursosDisponibles() {
    this.cursosExtraService.obtenerActivos().subscribe({
      next: (response: any) => {
        this.cursosDisponibles = response.body || [];
      },
      error: (error: any) => {
        console.error("Error al cargar cursos", error);
      }
    });
  }

  onCursoChange() {
    this.valoresGenerados = false;
    this.valores = [];
    this.tarifa = null;
    this.lineasFijas = [];
    this.paquetes = [];
    this.idPaqueteSeleccionado = null;
    this.model.id_institucion_cliente = null;
    this.conveniosCurso = [];

    if (!this.model.id_curso_extra) {
      this.cursoSeleccionado = null;
      return;
    }

    this.cursoSeleccionado = this.cursosDisponibles.find((c: any) => c.id == this.model.id_curso_extra);

    if (this.cursoSeleccionado) {
      this.model.fecha_inicio = this.cursoSeleccionado.fecha_inicio || '';
      // Curso permanente: las cuotas se generan hasta fin del año de la
      // inscripción, y se puede cambiar.
      this.model.fecha_fin = this.cursoSeleccionado.fecha_fin || this.finDeAnioInscripcion();
      this.cargarConvenios();
      this.cargarTarifa();
    }
  }

  // Solo los convenios activos: uno inactivo no deja inscribir, el back lo
  // rechaza.
  cargarConvenios() {
    this.cursosExtraXInstitucionesClienteService.obtenerPorCurso(this.model.id_curso_extra).subscribe({
      next: (response: any) => {
        const todos = response.body || [];
        this.conveniosCurso = todos.filter((c: any) => c.activo == 1);
      },
      error: (error: any) => {
        console.error("Error al cargar los convenios del curso", error);
      }
    });
  }

  // Al cambiar de convenio cambia la tarifa que aplica, asi que hay que
  // recargarla y descartar los valores que ya se hubieran generado.
  onConvenioChange() {
    this.valoresGenerados = false;
    this.valores = [];
    this.cargarTarifa();
  }

  // La tarifa que aplica la resuelve el back: la del convenio si existe, y si
  // no la interna del jardin. Es el mismo criterio con el que se generan las
  // cuentas, para que lo que se ve aqui sea lo que se va a cobrar.
  cargarTarifa() {
    const anio = this.cursoSeleccionado?.anio || this.institucionConfigService.getAnioAcademicoActual();
    this.tarifasCursosExtraService.obtenerVigente(this.model.id_curso_extra, anio, this.model.id_institucion_cliente).subscribe({
      next: (response: any) => {
        const tarifas = response.body || [];
        this.tarifa = tarifas.length > 0 ? tarifas[0] : null;
        if (this.tarifa) {
          // El back ya devuelve solo las filas activas del detalle.
          const detalle = this.tarifa.detalle || [];
          // valor_tarifa guarda lo que vale en la tarifa; valor es lo que se
          // va a cobrar y se puede bajar con un motivo
          this.lineasFijas = detalle
            .filter((l: any) => l.tipo !== 'paquete')
            .map((l: any) => ({
              ...l, valor: parseFloat(l.valor) || 0, valor_tarifa: parseFloat(l.valor) || 0,
              cuotas: parseInt(l.cuotas) || 1, motivo_descuento: ''
            }));
          this.paquetes = detalle
            .filter((l: any) => l.tipo === 'paquete')
            .map((l: any) => ({ ...l, valor: parseFloat(l.valor) || 0 }));
          // Con un solo paquete no hay nada que escoger.
          this.idPaqueteSeleccionado = this.paquetes.length === 1 ? this.paquetes[0].id : null;
          this.valorPaquete = this.paquetes.length === 1 ? this.paquetes[0].valor : 0;
          this.motivoPaquete = '';
        } else {
          this.lineasFijas = [];
          this.paquetes = [];
          this.idPaqueteSeleccionado = null;
          this.valorPaquete = 0;
          Swal.fire('Advertencia', `No hay tarifa configurada para el curso en el año ${anio}`, 'warning');
        }
      },
      error: (error: any) => {
        console.error("Error al cargar tarifa", error);
      }
    });
  }

  // ==================== INPUTS DE VALORES ====================

  onValorMatriculaInput(event: any) {
    let valorStr = event.target.value.replace(/\./g, '').replace(/\D/g, '');
    this.valorMatricula = valorStr ? parseInt(valorStr) : 0;
    event.target.value = this.valorMatricula > 0 ? this.valorMatricula.toLocaleString('es-CO') : '';
  }

  onValorPensionInput(event: any) {
    let valorStr = event.target.value.replace(/\./g, '').replace(/\D/g, '');
    this.valorPension = valorStr ? parseInt(valorStr) : 0;
    event.target.value = this.valorPension > 0 ? this.valorPension.toLocaleString('es-CO') : '';
  }

  onValorUnicoInput(event: any) {
    let valorStr = event.target.value.replace(/\./g, '').replace(/\D/g, '');
    this.valorUnico = valorStr ? parseInt(valorStr) : 0;
    event.target.value = this.valorUnico > 0 ? this.valorUnico.toLocaleString('es-CO') : '';
  }

  onValorLineaInput(event: any, linea: any) {
    const valorStr = event.target.value.replace(/\./g, '').replace(/\D/g, '');
    linea.valor = valorStr ? parseInt(valorStr) : 0;
    event.target.value = linea.valor > 0 ? linea.valor.toLocaleString('es-CO') : '';
  }

  // Al cambiar de paquete se propone su valor, que se puede ajustar.
  onPaqueteChange() {
    const paquete = this.paqueteSeleccionado();
    this.valorPaquete = paquete ? paquete.valor : 0;
    this.motivoPaquete = '';
    this.valoresGenerados = false;
    this.valores = [];
  }

  onValorPaqueteInput(event: any) {
    const valorStr = event.target.value.replace(/\./g, '').replace(/\D/g, '');
    this.valorPaquete = valorStr ? parseInt(valorStr) : 0;
    event.target.value = this.valorPaquete > 0 ? this.valorPaquete.toLocaleString('es-CO') : '';
  }

  paqueteSeleccionado(): any {
    return this.paquetes.find((p: any) => p.id == this.idPaqueteSeleccionado) || null;
  }

  // Se cobra menos que la tarifa: el motivo es obligatorio
  lineaConDescuento(linea: any): boolean {
    return linea.valor > 0 && linea.valor < linea.valor_tarifa;
  }

  paqueteConDescuento(): boolean {
    const paquete = this.paqueteSeleccionado();
    return !!paquete && this.valorPaquete > 0 && this.valorPaquete < paquete.valor;
  }

  cuotaConDescuento(v: ValorGenerado): boolean {
    return v.valor_base !== null && v.valor < v.valor_base;
  }

  getNombreTipoLinea(tipo: string): string {
    switch (tipo) {
      case 'matricula': return 'Matrícula';
      case 'pension': return 'Pensión mensual';
      default: return 'Cobro único';
    }
  }

  // ==================== GENERACIÓN DE VALORES ====================

  generarValores() {
    if (!this.model.id_curso_extra) {
      Swal.fire('Advertencia', 'Seleccione un curso', 'warning');
      return;
    }
    if (!this.model.fecha_inscripcion) {
      Swal.fire('Advertencia', 'Debe indicar la fecha de inscripción', 'warning');
      return;
    }
    // La fecha de inicio es informativa y un curso permanente no la tiene;
    // la de fin es el tope de las cuotas.
    if (!this.model.fecha_fin) {
      Swal.fire('Advertencia', 'Debe indicar la fecha fin', 'warning');
      return;
    }
    if (this.paquetes.length > 0 && !this.idPaqueteSeleccionado) {
      Swal.fire('Advertencia', 'Seleccione el paquete de sesiones que compró', 'warning');
      return;
    }
    const sinMotivo = this.lineasFijas.find((l: any) => this.lineaConDescuento(l) && !(l.motivo_descuento || '').trim());
    if (sinMotivo) {
      Swal.fire('Advertencia', `Escriba el motivo del descuento de ${sinMotivo.nombre_producto}`, 'warning');
      return;
    }
    if (this.paqueteConDescuento() && !this.motivoPaquete.trim()) {
      Swal.fire('Advertencia', 'Escriba el motivo del descuento del paquete', 'warning');
      return;
    }
    const hayFijos = this.lineasFijas.some((l: any) => l.valor > 0);
    if (!hayFijos && !(this.idPaqueteSeleccionado && this.valorPaquete > 0)) {
      Swal.fire('Advertencia', 'Debe haber al menos un valor para cobrar (matrícula, pensión, cobro único o paquete)', 'warning');
      return;
    }

    if (this.valoresGenerados && this.valores.length > 0) {
      Swal.fire({
        title: '¿Regenerar valores?',
        text: 'Esto reemplazará los valores actuales.',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, regenerar',
        cancelButtonText: 'Cancelar'
      }).then((result) => {
        if (result.isConfirmed) {
          this.ejecutarGeneracion();
        }
      });
    } else {
      this.ejecutarGeneracion();
    }
  }

  // 31 de diciembre del año de la fecha de inscripción (o del año actual)
  private finDeAnioInscripcion(): string {
    const anio = this.model.fecha_inscripcion
      ? this.model.fecha_inscripcion.substring(0, 4)
      : String(new Date().getFullYear());
    return `${anio}-12-31`;
  }

  private ejecutarGeneracion() {
    this.valores = [];
    // Las cuotas arrancan en la fecha de inscripcion, no en la de inicio del curso:
    // quien entra tarde solo paga desde que entra. La fecha fin del curso es el tope.
    const fechaInicio = new Date(this.model.fecha_inscripcion + 'T00:00:00');
    const fechaFin = new Date(this.model.fecha_fin + 'T00:00:00');
    const nombreCurso = this.cursoSeleccionado?.nombre || 'Curso';

    this.lineasFijas.forEach((linea: any) => {
      if (!linea.valor || linea.valor <= 0) return;

      // Pensión mensual (desde la fecha de inscripción, no día 1)
      if (linea.tipo === 'pension') {
        const current = new Date(fechaInicio);
        while (current <= fechaFin) {
          this.valores.push({
            id_producto_servicio: linea.id_producto_servicio,
            nombre_producto: linea.nombre_producto || 'Pensión',
            fecha: this.formatearFechaISO(current),
            valor: linea.valor,
            tipo: 'pension',
            detalle: `Pensión ${nombreCurso} - ${this.formatearMesAnio(current)}`,
            valor_base: linea.valor_tarifa,
            motivo_descuento: this.lineaConDescuento(linea) ? linea.motivo_descuento.trim() : ''
          });

          const siguiente = new Date(current);
          siguiente.setMonth(siguiente.getMonth() + 1);
          current.setTime(siguiente.getTime());
        }
        return;
      }

      // Matrícula y cobro único (diferidos por cuotas desde la fecha de inscripción)
      const cuotas = linea.cuotas || 1;
      const valorCuota = Math.round((linea.valor / cuotas) * 100) / 100;
      const baseCuota = Math.round((linea.valor_tarifa / cuotas) * 100) / 100;
      for (let i = 0; i < cuotas; i++) {
        const fechaCuota = new Date(fechaInicio);
        fechaCuota.setMonth(fechaCuota.getMonth() + i);

        this.valores.push({
          id_producto_servicio: linea.id_producto_servicio,
          nombre_producto: linea.nombre_producto || this.getNombreTipoLinea(linea.tipo),
          fecha: this.formatearFechaISO(fechaCuota),
          valor: valorCuota,
          tipo: linea.tipo === 'matricula' ? 'matricula' : 'unico',
          detalle: linea.tipo === 'matricula'
            ? `Matrícula ${nombreCurso} - Cuota ${i + 1}/${cuotas}`
            : `${nombreCurso} - Cuota ${i + 1}/${cuotas}`,
          valor_base: baseCuota,
          motivo_descuento: this.lineaConDescuento(linea) ? linea.motivo_descuento.trim() : ''
        });
      }
    });

    // Paquete de sesiones: un solo cobro en la fecha de inscripción, porque
    // el paquete se paga antes de empezar.
    const paquete = this.paqueteSeleccionado();
    if (paquete && this.valorPaquete > 0) {
      const vigencia = paquete.vigencia_dias ? ` (vigencia ${paquete.vigencia_dias} días)` : '';
      this.valores.push({
        id_producto_servicio: paquete.id_producto_servicio,
        nombre_producto: paquete.nombre_producto || 'Paquete de sesiones',
        fecha: this.formatearFechaISO(fechaInicio),
        valor: this.valorPaquete,
        tipo: 'paquete',
        detalle: `${nombreCurso} - ${paquete.numero_sesiones} sesiones${vigencia}`,
        valor_base: paquete.valor,
        motivo_descuento: this.paqueteConDescuento() ? this.motivoPaquete.trim() : ''
      });
    }

    this.valores.sort((a, b) => a.fecha.localeCompare(b.fecha));
    this.valoresGenerados = true;
    this.calcularResumen();
  }

  calcularResumen() {
    this.resumen = { total_matricula: 0, total_pension: 0, total_unico: 0, total_paquete: 0, total_general: 0, cuentas: this.valores.length };
    this.valores.forEach(v => {
      if (v.tipo === 'matricula') this.resumen.total_matricula += v.valor;
      else if (v.tipo === 'pension') this.resumen.total_pension += v.valor;
      else if (v.tipo === 'paquete') this.resumen.total_paquete += v.valor;
      else this.resumen.total_unico += v.valor;
    });
    this.resumen.total_general = this.resumen.total_matricula + this.resumen.total_pension +
      this.resumen.total_unico + this.resumen.total_paquete;
  }

  // ==================== EDICIÓN DE VALORES EN TABLA ====================

  onValorTablaInput(event: any, valor: ValorGenerado) {
    let valorStr = event.target.value.replace(/\./g, '').replace(/\D/g, '');
    valor.valor = valorStr ? parseInt(valorStr) : 0;
    if (valor.valor > 0) {
      event.target.value = valor.valor.toLocaleString('es-CO');
    } else {
      event.target.value = '';
    }
    this.calcularResumen();
  }

  onBlurValorTabla(event: any, valor: ValorGenerado) {
    event.target.value = this.formatearNumero(valor.valor);
  }

  onFechaChange(valor: ValorGenerado) {
    this.calcularResumen();
  }

  eliminarValor(index: number) {
    this.valores.splice(index, 1);
    this.calcularResumen();
  }

  // ==================== VALIDACIONES ====================

  validarSumas(): boolean {
    // Matrícula y cobro único se reparten en cuotas: la suma de las cuotas de
    // cada fila tiene que dar el valor configurado. La pensión no se valida
    // porque es un valor por mes.
    for (const linea of this.lineasFijas) {
      if (linea.tipo === 'pension' || !linea.valor || linea.valor <= 0) continue;

      const suma = this.valores
        .filter(v => v.id_producto_servicio === linea.id_producto_servicio)
        .reduce((s, v) => s + v.valor, 0);
      const diferencia = Math.abs(suma - linea.valor);
      if (diferencia > 1) {
        Swal.fire({
          title: `Error en valores de ${this.getNombreTipoLinea(linea.tipo).toLowerCase()}`,
          html: `La suma de cuotas de <strong>${linea.nombre_producto}</strong> (<strong>${this.formatearMoneda(suma)}</strong>) no coincide con el valor configurado (<strong>${this.formatearMoneda(linea.valor)}</strong>).<br>Diferencia: ${this.formatearMoneda(diferencia)}`,
          icon: 'error'
        });
        return false;
      }
    }

    return true;
  }

  async validarFechas(): Promise<boolean> {
    const inicio = new Date(this.model.fecha_inscripcion + 'T00:00:00');
    const fin = new Date(this.model.fecha_fin + 'T00:00:00');
    const fueraDeRango: ValorGenerado[] = [];

    this.valores.forEach(v => {
      const fecha = new Date(v.fecha + 'T00:00:00');
      if (fecha < inicio || fecha > fin) {
        fueraDeRango.push(v);
      }
    });

    if (fueraDeRango.length > 0) {
      const result = await Swal.fire({
        title: 'Fechas fuera de rango',
        html: `Hay <strong>${fueraDeRango.length}</strong> cobro(s) con fecha fuera del período ${this.model.fecha_inscripcion} al ${this.model.fecha_fin}.<br><br>¿Desea continuar de todas formas?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Sí, continuar',
        cancelButtonText: 'Cancelar'
      });
      return result.isConfirmed;
    }

    return true;
  }

  // ==================== GUARDAR INSCRIPCIÓN ====================

  guardar() {
    this.submitted = true;

    if (!this.model.id_curso_extra) {
      Swal.fire('Advertencia', 'Debe seleccionar un curso', 'warning');
      return;
    }

    if (!this.model.fecha_inscripcion) {
      Swal.fire('Advertencia', 'Debe indicar la fecha de inscripción', 'warning');
      return;
    }

    // Sin esto un segundo clic crea una inscripcion duplicada.
    if (this.idInscripcion) {
      Swal.fire('Advertencia', 'El estudiante ya quedó inscrito. Continúe con la generación de cuentas.', 'warning');
      return;
    }

    this.guardando = true;

    const data = {
      id_estudiante: this.idEstudiante,
      id_curso_extra: this.model.id_curso_extra,
      fecha_inscripcion: this.model.fecha_inscripcion,
      anio: this.cursoSeleccionado?.anio || this.institucionConfigService.getAnioAcademicoActual(),
      id_institucion_cliente: this.model.id_institucion_cliente
    };

    this.estudiantesXCursosExtraService.crear(data).subscribe({
      next: (response: any) => {
        this.guardando = false;
        this.idInscripcion = response.id;
        Swal.fire({
          toast: true, position: 'top-end', icon: 'success',
          title: 'Estudiante inscrito correctamente',
          showConfirmButton: false, timer: 2000
        });
      },
      error: (error: any) => {
        this.guardando = false;
        console.error("Error al inscribir", error);
        // El back responde 400 con el motivo (fecha limite, edad o cupo).
        const mensaje = error?.error?.error ? error.error.error : 'No se pudo inscribir al estudiante';
        Swal.fire('Error', mensaje, 'error');
      }
    });
  }

  // ==================== GENERAR CUENTAS POR COBRAR ====================

  async generarCuentasPorCobrar() {
    if (!this.idInscripcion || !this.valoresGenerados || this.valores.length === 0) {
      Swal.fire('Error', 'Primero debe guardar la inscripción y generar los valores', 'error');
      return;
    }

    if (!this.validarSumas()) return;

    // Una cuota que quedó por debajo de su tarifa necesita el motivo
    const cuotaSinMotivo = this.valores.find(v => this.cuotaConDescuento(v) && !(v.motivo_descuento || '').trim());
    if (cuotaSinMotivo) {
      Swal.fire('Falta el motivo', `Escriba el motivo del descuento de ${cuotaSinMotivo.nombre_producto} (${cuotaSinMotivo.fecha}).`, 'warning');
      return;
    }

    const fechasOk = await this.validarFechas();
    if (!fechasOk) return;

    Swal.fire({
      title: 'Generar Cuentas por Cobrar',
      html: `Se generarán <strong>${this.valores.length}</strong> cuentas por un total de <strong>${this.formatearMoneda(this.resumen.total_general)}</strong>.<br><br>¿Desea continuar?`,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Sí, generar',
      cancelButtonText: 'Cancelar',
      confirmButtonColor: '#26a69a'
    }).then((result) => {
      if (result.isConfirmed) {
        this.ejecutarGeneracionCuentas();
      }
    });
  }

  private ejecutarGeneracionCuentas() {
    this.generandoCuentas = true;

    Swal.fire({
      title: 'Generando cuentas...',
      text: 'Por favor espere',
      allowOutsideClick: false,
      didOpen: () => { Swal.showLoading(); }
    });

    const idUsuario = this.utilService.obtenerIdUsuarioActual();

    const data = {
      id_persona: this.estudiante.id_persona,
      id_usuario: idUsuario,
      id_curso_extra: this.model.id_curso_extra,
      id_inscripcion: this.idInscripcion,
      valores: this.valores.map(v => ({
        id_producto_servicio: v.id_producto_servicio,
        nombre_producto: v.nombre_producto,
        fecha: v.fecha,
        valor: v.valor,
        tipo: v.tipo,
        detalle: v.detalle,
        valor_base: v.valor_base,
        motivo_descuento: this.cuotaConDescuento(v) ? (v.motivo_descuento || '').trim() : null
      }))
    };

    this.cuentasPorCobrarService.generarDesdeCursoExtra(data).subscribe({
      next: (response: any) => {
        this.generandoCuentas = false;
        Swal.close();

        if (response.error) {
          Swal.fire('Error', response.error, 'error');
          return;
        }

        if (response.duplicados && response.duplicados.length > 0) {
          let tablaHTML = '<table class="table table-sm table-bordered" style="font-size: 0.85rem;">';
          tablaHTML += '<thead><tr><th>Producto</th><th>Fecha</th></tr></thead><tbody>';
          response.duplicados.forEach((dup: any) => {
            tablaHTML += `<tr><td>${dup.nombre_producto}</td><td>${dup.fecha}</td></tr>`;
          });
          tablaHTML += '</tbody></table>';

          Swal.fire({
            title: 'Cuentas duplicadas',
            html: `Ya existen cuentas por cobrar para:<br><br>${tablaHTML}`,
            icon: 'warning',
            width: 600
          });
          return;
        }

        Swal.fire({
          title: 'Cuentas generadas',
          html: `Se crearon <strong>${response.cuentas_creadas}</strong> cuentas por cobrar:<br><br>
                 ${response.total_matricula > 0 ? 'Matrícula: <strong>' + this.formatearMoneda(response.total_matricula) + '</strong><br>' : ''}
                 ${response.total_pension > 0 ? 'Pensiones: <strong>' + this.formatearMoneda(response.total_pension) + '</strong><br>' : ''}
                 ${response.total_unico > 0 ? 'Cobro único y paquetes: <strong>' + this.formatearMoneda(response.total_unico) + '</strong><br>' : ''}
                 <hr>
                 <strong>Total: ${this.formatearMoneda(response.total_general)}</strong>`,
          icon: 'success',
          confirmButtonColor: '#26a69a'
        });
      },
      error: (error: any) => {
        this.generandoCuentas = false;
        Swal.close();
        console.error('Error al generar cuentas:', error);
        Swal.fire('Error', 'No se pudieron generar las cuentas por cobrar', 'error');
      }
    });
  }

  // ==================== UTILIDADES ====================

  formatearFechaISO(fecha: Date): string {
    const y = fecha.getFullYear();
    const m = String(fecha.getMonth() + 1).padStart(2, '0');
    const d = String(fecha.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  formatearMesAnio(fecha: Date): string {
    const mes = this.nombresMeses[fecha.getMonth() + 1];
    return `${mes} ${fecha.getFullYear()}`;
  }

  formatearNumero(valor: number): string {
    if (!valor || valor === 0) return '';
    return valor.toLocaleString('es-CO');
  }

  formatearMoneda(valor: number): string {
    return valor?.toLocaleString('es-CO', {
      style: 'currency', currency: 'COP', minimumFractionDigits: 0
    }) || '$0';
  }

  getTipoLabel(tipo: string): string {
    switch (tipo) {
      case 'matricula': return 'Matrícula';
      case 'pension': return 'Pensión';
      case 'unico': return 'Cobro Único';
      case 'paquete': return 'Paquete';
      default: return tipo;
    }
  }

  getTipoBadgeClass(tipo: string): string {
    switch (tipo) {
      case 'matricula': return 'bg-primary';
      case 'pension': return 'bg-success';
      case 'unico': return 'bg-info';
      case 'paquete': return 'bg-warning text-dark';
      default: return 'bg-secondary';
    }
  }

  volver() {
    this.router.navigate(['/estudiantes/cursos-extra/' + this.idEstudiante]);
  }
}