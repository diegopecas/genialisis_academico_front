import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import Swal from 'sweetalert2';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from '../../../../common/header/header.component';
import { PagosRecibidosService } from '../../../../services/pagos-recibidos.service';
import { CuentasPorCobrarService } from '../../../../services/cuentas-por-cobrar.service';
import { EstudiantesService } from '../../../../services/estudiantes.service';
import { TiposPagosService } from '../../../../services/tipos-pagos.service';
import { AcudientesService } from '../../../../services/acudientes.service';
import { UtilService } from '../../../../common/constantes/util.service';
import { ConfiguracionGlobalService } from '../../../../services/configuracion-global.service';
import { CuentaPagadaService } from '../../../../services/cuenta-pagada.service';
import { ReportesPagoService } from '../../../../services/reportes-pago.service';
import { DocumentosPersonasService } from '../../../../services/documentos-personas.service';
import { environment } from '../../../../../environments/environment';


// Interfaz para el modelo de pago
interface PagoModel {
  id: string;
  fecha: string;
  id_estudiante: string;
  id_acudiente: string;
  id_tipo_pago: string;
  valor_recibido: number;
  saldo: number;
  observaciones: string;
  referencia_bancaria: string;
  id_usuario_registro: string | null;
  fecha_registro?: string;
  fecha_contabilizacion?: string | null;
  id_usuario_contable?: string | null;
  anulado?: number;
  fecha_anulacion?: string | null;
  id_usuario_anulacion?: string | null;
  nombre_completo_usuario_registro?: string;
  nombre_completo_usuario_contable?: string;
  nombre_completo_usuario_anulacion?: string;
  id_documento_persona?: string | null;
  cuentas_aplicadas: CuentaAplicadaModel[];
}

// Interfaz para el modelo de cuenta aplicada
interface CuentaAplicadaModel {
  id: string;
  id_cuenta_por_cobrar: string;
  id_pago_recibido: string | null;
  valor_aplicado: number;
  // Parte del abono imputada a intereses de mora. valor_aplicado sigue siendo
  // SOLO capital, para no alterar el saldo que calcula el backend.
  valor_aplicado_mora: number;
  fecha: string;
}
// Interfaz para las cuentas pagadas
interface CuentaPagada {
  id: string;
  id_cuenta_por_cobrar: string;
  id_pago_recibido: string;
  valor_aplicado: number;
  valor_aplicado_mora: number;
  fecha: string;
  nombre_producto_servicio: string;
}
@Component({
  selector: 'app-crear-pagos-recibidos',
  templateUrl: './crear-pagos-recibidos.component.html',
  styleUrl: './crear-pagos-recibidos.component.scss',
  standalone: true,
  imports: [CommonModule, FormsModule, HeaderComponent]
})
export class CrearPagosRecibidosComponent implements OnInit {

  // Propiedades principales
  public id = "0";
  public idEstudiante = "0";
  public accion = "";
  public editable = false;
  public submitted = false;
  public estudiante: any;
  public nombre_estudiante = "";
  public titulo = "Registro de Pagos";
  public regresar = '/estudiantes/pagos/';

  // Propiedades para el manejo de cuentas y pagos
  public cuentasPorCobrar: any[] = [];
  public cuentasSeleccionadas: string[] = [];
  /* Orden de imputacion del abono cuando no alcanza para todo. Sale de
     configuracion_global (mora_aplicar_pago_primero): MORA o CAPITAL. */
  public aplicarPagoPrimero: string = 'MORA';
  public valorPorAplicar = 0;
  public valorRestante = 0;

  // Variables para la máscara del valor recibido
  public valorRecibidoFormateado: string = '';

  // Listas para los selectores
  public listas = {
    tiposPago: [] as any[],
    acudientes: [] as any[]
  }

  // Modelo de datos principal
  public model: PagoModel = {
    id: '',
    fecha: "",
    id_estudiante: "",
    id_acudiente: "",
    id_tipo_pago: "",
    valor_recibido: 0,
    saldo: 0,
    observaciones: "",
    referencia_bancaria: "",
    id_usuario_registro: null,
    cuentas_aplicadas: []
  };

  public pagoContabilizado = false;

  // Reportes de pago del portal de padres
  public reportesPendientes: any[] = [];
  public reporteSeleccionado: any = null;
  public reporteAsociado: any = null;

  // Comprobante de pago (archivo) y datos extraídos por IA
  public archivoComprobante: File | null = null;
  public analizandoIA = false;
  public bancoDetectadoIA: string | null = null;
  // Valor total leído del comprobante. Se conserva aparte de valor_recibido
  // porque un mismo comprobante puede repartirse entre varios estudiantes.
  public valorComprobanteIA: number | null = null;
  // Última referencia ya consultada al backend, para no repetir la verificación
  // temprana en cada blur si la referencia no cambió.
  private referenciaVerificada: string | null = null;
  public idDocumentoPersona: string | null = null;
  // Código (estable) del tipo de documento para comprobantes de pago.
  // El back lo resuelve a su UUID por código dentro del tenant.
  private readonly CODIGO_TIPO_DOCUMENTO_COMPROBANTE = 'comprobante_pago';


  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private pagosService: PagosRecibidosService,
    private cuentasService: CuentasPorCobrarService,
    private estudiantesService: EstudiantesService,
    private tiposPagosService: TiposPagosService,
    private acudientesService: AcudientesService,
    private cuentaPagadaService: CuentaPagadaService,
    private reportesPagoService: ReportesPagoService,
    private documentosService: DocumentosPersonasService,
    private utilService: UtilService,
    private configuracionGlobalService: ConfiguracionGlobalService
  ) { }

  ngOnInit() {
    this.cargarOrdenImputacion();

    this.route.params.subscribe(params => {
      this.accion = params['accion'];
      this.id = params['id'];
      this.idEstudiante = params['idEstudiante'];
      this.model.id_estudiante = this.idEstudiante;
      
      // Verificar si viene desde el listado global
      this.route.queryParams.subscribe(queryParams => {
        if (queryParams['origen'] === 'global') {
          this.regresar = '/administracion/financiero/gestion-pagos-recibidos';
        } else {
          this.regresar = '/estudiantes/pagos/' + this.idEstudiante;
        }
      });
      
      this.obtenerEstudiante(this.idEstudiante);

      switch (this.accion) {
        case 'crear':
          this.editable = true;
          this.consultarListas();
          this.cargarReportesPendientes();
          const hoy = new Date();
          this.model.fecha = hoy.toISOString().split('T')[0];
          this.model.id_usuario_registro = this.utilService.obtenerIdUsuarioActual();
          break;
        case 'editar':
          this.editable = true;
          this.consultarListas();
          this.obtenerPago(this.id);
          this.cargarReporteAsociado();
          break;
        case 'consultar':
          this.editable = false;
          this.consultarListas();
          this.obtenerPago(this.id);
          this.cargarReporteAsociado();
          break;
      }
    });
  }

  // Métodos para cargar datos iniciales
  consultarListas() {
    // Obtener tipos de pago desde el servicio
    this.tiposPagosService.obtenerTodos().subscribe((response: any) => {
      this.listas.tiposPago = response.body;
    });

    // La lista de acudientes se cargará después de obtener el estudiante
    this.listas.acudientes = [];
  }

  obtenerEstudiante(id_estudiante: any) {
    this.estudiantesService.obtenerById(id_estudiante).subscribe((response: any) => {
      const body = response.body as any[];
      this.estudiante = body[0];
      this.nombre_estudiante = [
        this.estudiante.primer_nombre,
        this.estudiante.segundo_nombre,
        this.estudiante.primer_apellido,
        this.estudiante.segundo_apellido
      ].filter(Boolean).join(' ');
      this.titulo = this.titulo + " para " + this.nombre_estudiante;

      // Una vez obtenido el estudiante, cargar los acudientes
      this.cargarAcudientes();
      // Y también cargar las cuentas por cobrar
      if (this.accion === 'crear') {
        this.obtenerCuentasPorCobrar();
      }

    });
  }

  cargarAcudientes() {
    // Obtener los acudientes del estudiante desde el servicio
    this.acudientesService.obtenerPorEstudiante(this.idEstudiante).subscribe({
      next: (response: any) => {
        const acudientesData = response.body;
        console.log('Acudientes obtenidos:', acudientesData);

        // Filtrar acudientes activos y responsables de pago
        // ¡IMPORTANTE! Usar el ID del registro de acudiente, no el ID de persona
        this.listas.acudientes = acudientesData
          .filter((acudiente: any) => acudiente.activo == 1 && acudiente.es_responsable_pago == 1)
          .map((acudiente: any) => ({
            id: acudiente.id,
            nombre: acudiente.nombre_persona + ' (' + acudiente.nombre_tipo_acudiente + ')'
          }));
        // Agregar al estudiante como una opción de acudiente
        this.listas.acudientes.push({
          id: null,
          nombre: this.nombre_estudiante + ' (Mismo estudiante)'
        });
        console.log('Lista de acudientes procesada:', this.listas.acudientes);

        // Seleccionar al primer acudiente responsable de pago como default
        if (this.listas.acudientes.length > 0 && this.accion === 'crear') {
          this.model.id_acudiente = this.listas.acudientes[0].id;
        } else if (this.listas.acudientes.length === 0) {
          Swal.fire('Advertencia', 'No se encontraron acudientes responsables de pago para este estudiante. Debe agregar un acudiente antes de registrar pagos.', 'warning');
        }

      },
      error: (error) => {
        console.error('Error al cargar acudientes:', error);
        this.listas.acudientes = [];
        Swal.fire('Error', 'No se pudieron cargar los acudientes. Por favor, intente nuevamente.', 'error');
      }
    });
  }


  // El método obtenerPago para cargar todas las cuentas pendientes
  // cuando estamos en modo editar y hay saldo a favor
  obtenerPago(id: any) {
    // Guardar el id_estudiante actual antes de obtener el pago
    const idEstudianteActual = this.model.id_estudiante;

    this.pagosService.obtenerById(id).subscribe((response: any) => {
      const body = response.body;
      this.model = body[0];

      // Si no viene id_estudiante en la respuesta, usar el que teníamos
      if (!this.model.id_estudiante) {
        this.model.id_estudiante = idEstudianteActual || this.idEstudiante;
      }

      this.model.fecha = this.formatDate(this.model.fecha);

      // Verificar si el pago está contabilizado o anulado
      this.pagoContabilizado = !!this.model.fecha_contabilizacion || !!this.model.id_usuario_contable;

      // Si el pago está contabilizado o anulado, solo permitir editar observaciones cuando estamos en modo editar
      if ((this.pagoContabilizado) && this.accion === 'editar') {
        this.editable = false;
      }

      // Formatear el valor recibido cuando se obtiene un pago existente
      this.formatearValorRecibido(this.model.valor_recibido);

      // Si la acción es consultar o editar, primero cargamos las cuentas afectadas por el pago
      if (this.accion === 'consultar' || this.accion === 'editar') {
        this.obtenerCuentasPagadasPorPago(id).then(() => {
          // Si estamos en modo editar y hay saldo a favor y no está contabilizado ni anulado
          if (this.accion === 'editar' && this.model.saldo > 0 && !this.pagoContabilizado) {
            this.obtenerCuentasPendientesPorCobrar();
          }
        });
      } else {
        this.obtenerCuentasPorCobrar();
      }
      console.log("pago", this.model)
    });
  }



  formatDate(dateString: string): string {
    // Convierte la fecha al formato YYYY-MM-DD
    const date = new Date(dateString);
    return date.toISOString().split('T')[0];
  }
  // Método para obtener cuentas pagadas, convertido a Promise para encadenar operaciones
  obtenerCuentasPagadasPorPago(idPago: any): Promise<void> {
    return new Promise((resolve, reject) => {
      // Obtener las cuentas pagadas asociadas a este pago
      this.cuentaPagadaService.getByPagoRecibido(idPago).subscribe({
        next: (response: any) => {
          const cuentasPagadas: CuentaPagada[] = response.body;
          console.log('Cuentas pagadas por este pago:', cuentasPagadas);

          // Si hay cuentas pagadas, obtenemos los detalles de todas en una sola llamada
          if (cuentasPagadas && cuentasPagadas.length > 0) {
            // Limpiar las cuentas seleccionadas
            this.cuentasSeleccionadas = [];

            // Extraer todos los IDs de las cuentas por cobrar
            const idsCuentasPorCobrar = cuentasPagadas.map(cp => cp.id_cuenta_por_cobrar);

            // Hacer una sola llamada para obtener todas las cuentas
            this.cuentasService.obtenerMultiplesByIds(idsCuentasPorCobrar).subscribe({
              next: (respuesta: any) => {
                const cuentasObtenidas = respuesta.body;

                // Crear un mapa para acceso rápido
                const mapaCuentas = new Map<string, any>();
                cuentasObtenidas.forEach((cuenta: any) => {
                  mapaCuentas.set(cuenta.id, cuenta);
                });

                // Procesar las cuentas pagadas y asociar con los datos obtenidos
                this.cuentasPorCobrar = [];

                cuentasPagadas.forEach((cuentaPagada: CuentaPagada) => {
                  const cuenta = mapaCuentas.get(cuentaPagada.id_cuenta_por_cobrar);

                  if (cuenta) {
                    // Añadir el valor pagado de esta aplicación específica
                    cuenta.valor_aplicado_en_este_pago = cuentaPagada.valor_aplicado;

                    // Marcar esta cuenta como ya aplicada (para evitar modificaciones)
                    cuenta.ya_aplicada = true;

                    // Agregar la cuenta al array
                    this.cuentasPorCobrar.push(cuenta);

                    // Añadir la cuenta a las seleccionadas
                    this.cuentasSeleccionadas.push(cuentaPagada.id_cuenta_por_cobrar);
                  }
                });

                console.log('Cuentas por cobrar cargadas:', this.cuentasPorCobrar);

                // Actualizar las cuentas aplicadas en el modelo
                this.model.cuentas_aplicadas = cuentasPagadas.map((cp: CuentaPagada) => ({
                  id: cp.id,
                  id_cuenta_por_cobrar: cp.id_cuenta_por_cobrar,
                  id_pago_recibido: cp.id_pago_recibido,
                  valor_aplicado: cp.valor_aplicado,
                  valor_aplicado_mora: cp.valor_aplicado_mora || 0,
                  fecha: cp.fecha
                }));

                // Actualizar los valores formateados
                this.model.cuentas_aplicadas.forEach(cuenta => {
                  this.formatearValorAplicado(cuenta.id_cuenta_por_cobrar, cuenta.valor_aplicado);
                });

                // Actualizar totales
                this.actualizarTotales();
                resolve();
              },
              error: (error) => {
                console.error('Error al obtener cuentas por cobrar:', error);
                Swal.fire('Error', 'No se pudieron cargar los detalles de las cuentas afectadas por este pago', 'error');
                reject(error);
              }
            });

          } else {
            this.cuentasPorCobrar = [];
            console.log('No se encontraron cuentas aplicadas para este pago');
            resolve();
          }
        },
        error: error => {
          console.error('Error al obtener cuentas pagadas:', error);
          Swal.fire('Error', 'No se pudieron cargar las cuentas afectadas por este pago', 'error');
          reject(error);
        }
      });
    });
  }
  // Método para obtener cuentas pendientes por cobrar (para usar el saldo a favor)
  obtenerCuentasPendientesPorCobrar() {
    this.cuentasService.obtenerTodosXPersona(this.estudiante?.id_persona).subscribe((response: any) => {
      // Filtrar solo cuentas con saldo > 0 y que no estén ya en cuentasPorCobrar
      const cuentasPendientes = response.body
        .filter((cuenta: any) => cuenta.saldo > 0 || Number(cuenta.saldo_mora) > 0)
        .filter((cuenta: any) => !this.cuentasPorCobrar.some(c => c.id === cuenta.id));

      // Añadir estas cuentas pendientes al array existente, marcándolas como no aplicadas aún
      cuentasPendientes.forEach((cuenta: any) => {
        cuenta.ya_aplicada = false; // Marcar como nueva cuenta, no aplicada aún
        this.cuentasPorCobrar.push(cuenta);
      });

      console.log('Cuentas por cobrar totales (aplicadas + pendientes):', this.cuentasPorCobrar);
    });
  }

  obtenerCuentasPorCobrar() {
    this.cuentasService.obtenerTodosXPersona(this.estudiante?.id_persona).subscribe((response: any) => {
      // Se incluyen tambien las cuentas con capital en cero pero mora pendiente.
      this.cuentasPorCobrar = response.body.filter((cuenta: any) => cuenta.saldo > 0 || Number(cuenta.saldo_mora) > 0);
      console.log("obtenerCuentasPorCobrar", this.cuentasPorCobrar)
      // Si estamos editando, marcamos las cuentas que ya tienen pagos aplicados
      if (this.accion !== 'crear' && this.model.cuentas_aplicadas) {
        this.model.cuentas_aplicadas.forEach(cuentaAplicada => {
          this.cuentasSeleccionadas.push(cuentaAplicada.id_cuenta_por_cobrar);
        });
        // Actualizar totales
        this.actualizarTotales();
      }
    });
  }

  // Métodos para manipulación de cuentas y pagos
  toggleSeleccionCuenta(idCuenta: string) {
    // Verificar si la cuenta ya está aplicada
    const cuenta = this.cuentasPorCobrar.find(c => c.id === idCuenta);
    console.log("toggleSeleccionCuenta", cuenta);
    if (cuenta && cuenta.ya_aplicada) {
      // Si está ya aplicada, no permitir desmarcarla
      Swal.fire('Información', 'No se puede modificar una cuenta que ya ha sido aplicada a este pago', 'info');
      return;
    }

    const index = this.cuentasSeleccionadas.indexOf(idCuenta);
    if (index === -1) {
      // Agregamos la cuenta a las seleccionadas
      this.cuentasSeleccionadas.push(idCuenta);

      // Siempre asignar automáticamente el saldo pendiente de la cuenta
      if (cuenta) {
        const distribucion = this.distribuirAbono(cuenta);

        const indexCuentaAplicada = this.model.cuentas_aplicadas.findIndex(
          ca => ca.id_cuenta_por_cobrar === idCuenta
        );

        if (indexCuentaAplicada >= 0) {
          this.model.cuentas_aplicadas[indexCuentaAplicada].valor_aplicado = distribucion.capital;
          this.model.cuentas_aplicadas[indexCuentaAplicada].valor_aplicado_mora = distribucion.mora;
        } else {
          this.model.cuentas_aplicadas.push({
            id: '',
            id_cuenta_por_cobrar: idCuenta,
            id_pago_recibido: this.model.id || null,
            valor_aplicado: distribucion.capital,
            valor_aplicado_mora: distribucion.mora,
            fecha: this.model.fecha
          });
        }

        this.formatearValorAplicado(idCuenta, distribucion.capital);
      }
    } else {
      // Solo permitir desmarcar cuentas que no están ya aplicadas
      this.cuentasSeleccionadas.splice(index, 1);

      this.model.cuentas_aplicadas = this.model.cuentas_aplicadas.filter(
        ca => ca.id_cuenta_por_cobrar !== idCuenta
      );

      delete this.valoresAplicadosFormateados[idCuenta];
    }

    this.actualizarTotales();
  }

  /**
   * Lee de configuracion_global si el abono se imputa primero a intereses o a
   * capital. Si la clave no existe se conserva el valor por defecto (MORA) y
   * no se interrumpe el registro del pago.
   */
  cargarOrdenImputacion() {
    this.configuracionGlobalService.obtenerByClave('mora_aplicar_pago_primero').subscribe({
      next: (response: any) => {
        const body = response.body || response;
        if (body && body.valor_texto) {
          this.aplicarPagoPrimero = body.valor_texto;
        }
      },
      error: () => {
        // Sin configuracion se mantiene el orden estandar: intereses primero.
      }
    });
  }

  /**
   * Reparte lo que queda del pago entre intereses de mora y capital de una
   * cuenta. El orden lo define configuracion_global (mora_aplicar_pago_primero);
   * por defecto primero intereses, que es la imputacion estandar.
   *
   * Si el pago no alcanza, se cubre lo que se pueda del primer concepto y el
   * resto queda en cero.
   */
  distribuirAbono(cuenta: any): { capital: number; mora: number } {
    const saldoCapital = Number(cuenta.saldo) > 0 ? Number(cuenta.saldo) : 0;
    const saldoMora = Number(cuenta.saldo_mora) > 0 ? Number(cuenta.saldo_mora) : 0;

    /* Si no se ha digitado valor recibido, valorRestante puede venir en cero o
       negativo; en ese caso se propone cubrir todo y el usuario ajusta. */
    let disponible = this.valorRestante > 0 ? this.valorRestante : (saldoCapital + saldoMora);

    let capital = 0;
    let mora = 0;

    if (this.aplicarPagoPrimero === 'CAPITAL') {
      capital = Math.min(saldoCapital, disponible);
      disponible -= capital;
      mora = Math.min(saldoMora, disponible);
    } else {
      mora = Math.min(saldoMora, disponible);
      disponible -= mora;
      capital = Math.min(saldoCapital, disponible);
    }

    return { capital, mora };
  }

  // Métodos para la máscara de formato de moneda
  formatearValorRecibido(valor: number) {
    if (valor === null || valor === undefined) {
      this.valorRecibidoFormateado = '';
      return;
    }

    const valorStr = valor.toString();
    let parteEntera = valorStr.split('.')[0];
    const parteDecimal = valorStr.split('.')[1] || '';

    parteEntera = parteEntera.replace(/\B(?=(\d{3})+(?!\d))/g, ',');

    this.valorRecibidoFormateado = parteDecimal ? `${parteEntera}.${parteDecimal}` : parteEntera;
  }

  onInputValorRecibido(event: any) {
    const inputValue = event.target.value.replace(/[^\d.]/g, '');

    if (inputValue === '') {
      this.model.valor_recibido = 0;
      this.valorRecibidoFormateado = '';
    } else {
      this.model.valor_recibido = parseFloat(inputValue);
      this.formatearValorRecibido(this.model.valor_recibido);
    }

    this.actualizarValorRecibido();
  }

  actualizarValorRecibido() {
    this.actualizarTotales();
  }

  // Objeto para almacenar valores formateados de cada cuenta
  public valoresAplicadosFormateados: { [key: string]: string } = {};

  formatearValorAplicado(idCuenta: string, valor: number) {
    if (valor === null || valor === undefined) {
      this.valoresAplicadosFormateados[idCuenta] = '';
      return;
    }

    const valorStr = valor.toString();
    let parteEntera = valorStr.split('.')[0];
    const parteDecimal = valorStr.split('.')[1] || '';

    parteEntera = parteEntera.replace(/\B(?=(\d{3})+(?!\d))/g, ',');

    this.valoresAplicadosFormateados[idCuenta] = parteDecimal ? `${parteEntera}.${parteDecimal}` : parteEntera;
  }

  onInputValorAplicado(idCuenta: string, event: any) {
    const cuenta = this.cuentasPorCobrar.find(c => c.id === idCuenta);
    if (cuenta && cuenta.ya_aplicada) {
      this.formatearValorAplicado(idCuenta, cuenta.valor_aplicado_en_este_pago);
      Swal.fire('Información', 'No se puede modificar el valor de una cuenta que ya ha sido aplicada a este pago', 'info');
      return;
    }

    const inputValue = event.target.value.replace(/[^\d.]/g, '');

    if (inputValue === '') {
      this.actualizarValorAplicado(idCuenta, 0);
      this.valoresAplicadosFormateados[idCuenta] = '';
    } else {
      const nuevoValor = parseFloat(inputValue);
      this.actualizarValorAplicado(idCuenta, nuevoValor);
      this.formatearValorAplicado(idCuenta, nuevoValor);
    }
  }

  getValorAplicadoFormateado(idCuenta: string): string {
    if (!this.valoresAplicadosFormateados[idCuenta]) {
      if ((this.accion === 'consultar' || this.accion === 'editar') && this.cuentasPorCobrar) {
        const cuenta = this.cuentasPorCobrar.find(c => c.id === idCuenta);
        if (cuenta && cuenta.valor_aplicado_en_este_pago !== undefined) {
          this.formatearValorAplicado(idCuenta, cuenta.valor_aplicado_en_este_pago);
        } else {
          const valor = this.getCuentaAplicadaValor(idCuenta);
          this.formatearValorAplicado(idCuenta, valor);
        }
      } else {
        const valor = this.getCuentaAplicadaValor(idCuenta);
        this.formatearValorAplicado(idCuenta, valor);
      }
    }
    return this.valoresAplicadosFormateados[idCuenta];
  }

  actualizarValorAplicado(idCuenta: string, nuevoValor: number) {
    const cuenta = this.cuentasPorCobrar.find(c => c.id === idCuenta);
    if (!cuenta) return;

    if (nuevoValor > cuenta.saldo) {
      nuevoValor = cuenta.saldo;
      Swal.fire('Atención', `El valor no puede exceder el saldo pendiente de la cuenta (${this.formatearMoneda(cuenta.saldo)})`, 'warning');
      this.formatearValorAplicado(idCuenta, nuevoValor);
    }

    if (nuevoValor < 0) {
      nuevoValor = 0;
    }

    const index = this.model.cuentas_aplicadas.findIndex(ca => ca.id_cuenta_por_cobrar === idCuenta);
    if (index >= 0) {
      this.model.cuentas_aplicadas[index].valor_aplicado = nuevoValor;
    } else {
      this.model.cuentas_aplicadas.push({
        id: '',
        id_cuenta_por_cobrar: idCuenta,
        id_pago_recibido: this.model.id || null,
        valor_aplicado: nuevoValor,
        /* El campo editable es el de capital; la mora imputada se conserva
           como la calculo distribuirAbono() al seleccionar la cuenta. */
        valor_aplicado_mora: 0,
        fecha: this.model.fecha
      });
    }

    this.actualizarTotales();
  }

  actualizarTotales() {
    // Se suma capital + mora: los dos consumen el dinero recibido.
    const totalAplicado = this.model.cuentas_aplicadas.reduce(
      (sum, ca) => sum + Number(ca.valor_aplicado || 0) + Number(ca.valor_aplicado_mora || 0), 0
    );

    this.valorRestante = this.model.valor_recibido - totalAplicado;
    this.model.saldo = this.valorRestante;

    /* Sin alerta aquí: este método se recalcula en cada tecla del valor recibido
       y de los valores a pagar. Cuando el restante queda negativo se avisa en
       línea bajo el Saldo restante, y al grabar la validación lo bloquea. */
  }

  /* ------------------------------------------------------------------
     Totales de la tabla de cuentas por aplicar. Son metodos y no campos
     para que se recalculen solos mientras se digita en la columna A pagar.
     ------------------------------------------------------------------ */

  /** Suma una columna numerica de las cuentas listadas. */
  private sumarCuentas(campo: string): number {
    return this.cuentasPorCobrar.reduce((sum, cuenta) => sum + Number(cuenta[campo] || 0), 0);
  }

  totalValor(): number {
    return this.sumarCuentas('valor');
  }

  totalPagado(): number {
    return this.sumarCuentas('valor_pagado');
  }

  totalSaldo(): number {
    return this.sumarCuentas('saldo');
  }

  /** Mora pendiente de las cuentas listadas, no la que se va a aplicar. */
  totalMora(): number {
    return this.cuentasPorCobrar.reduce(
      (sum, cuenta) => sum + (Number(cuenta.saldo_mora) > 0 ? Number(cuenta.saldo_mora) : 0), 0
    );
  }

  /** Capital que se esta aplicando: es lo que se ve en la columna A pagar. */
  totalAPagar(): number {
    return this.model.cuentas_aplicadas.reduce((sum, ca) => sum + Number(ca.valor_aplicado || 0), 0);
  }

  /** Parte del pago imputada a intereses, que no se digita pero si consume el valor recibido. */
  totalMoraAplicada(): number {
    return this.model.cuentas_aplicadas.reduce((sum, ca) => sum + Number(ca.valor_aplicado_mora || 0), 0);
  }

  /** Lo que realmente descuenta del valor recibido: capital + mora. */
  totalAplicado(): number {
    return this.totalAPagar() + this.totalMoraAplicada();
  }

  formatearMoneda(valor: number): string {
    if (valor === null || valor === undefined) return '0';
    return valor.toLocaleString('es-CO', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  }

  distribuirValorEnCuentas() {
    if (this.model.valor_recibido <= 0) {
      Swal.fire('Atención', 'Debe ingresar un valor recibido mayor a cero para poder distribuir', 'warning');
      return;
    }

    if (this.cuentasPorCobrar.length === 0) {
      Swal.fire('Información', 'No hay cuentas pendientes para aplicar el pago', 'info');
      return;
    }

    this.cuentasSeleccionadas = [];
    this.model.cuentas_aplicadas = [];
    this.valoresAplicadosFormateados = {};

    const cuentasOrdenadas = [...this.cuentasPorCobrar]
      .sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime());

    const totalDeudaPendiente = cuentasOrdenadas.reduce((sum, cuenta) => sum + cuenta.saldo, 0);

    let valorRestante = this.model.valor_recibido;
    let totalAplicado = 0;

    for (const cuenta of cuentasOrdenadas) {
      if (valorRestante <= 0) break;

      this.cuentasSeleccionadas.push(cuenta.id);

      /* Se reparte entre intereses y capital con el mismo criterio que la
         seleccion manual, usando lo que queda del saldo a favor. */
      const saldoMoraCuenta = Number(cuenta.saldo_mora) > 0 ? Number(cuenta.saldo_mora) : 0;
      let disponibleCuenta = valorRestante;
      let moraAplicar = 0;
      let valorAplicar = 0;

      if (this.aplicarPagoPrimero === 'CAPITAL') {
        valorAplicar = Math.min(cuenta.saldo, disponibleCuenta);
        disponibleCuenta -= valorAplicar;
        moraAplicar = Math.min(saldoMoraCuenta, disponibleCuenta);
      } else {
        moraAplicar = Math.min(saldoMoraCuenta, disponibleCuenta);
        disponibleCuenta -= moraAplicar;
        valorAplicar = Math.min(cuenta.saldo, disponibleCuenta);
      }

      valorRestante -= (valorAplicar + moraAplicar);
      totalAplicado += (valorAplicar + moraAplicar);

      this.model.cuentas_aplicadas.push({
        id: '',
        id_cuenta_por_cobrar: cuenta.id,
        id_pago_recibido: this.model.id || null,
        valor_aplicado: valorAplicar,
        valor_aplicado_mora: moraAplicar,
        fecha: this.model.fecha
      });

      this.formatearValorAplicado(cuenta.id, valorAplicar);
    }

    this.valorRestante = valorRestante;
    this.model.saldo = valorRestante;

    let mensaje = '';
    let tipoAlerta: 'success' | 'info' = 'success';

    if (valorRestante > 0 && this.cuentasSeleccionadas.length > 0) {
      mensaje = `Del valor recibido ${this.formatearMoneda(this.model.valor_recibido)}, se aplicarán ${this.formatearMoneda(totalAplicado)} a las ${this.cuentasSeleccionadas.length} cuentas pendientes.\n\nQuedará un saldo a favor de ${this.formatearMoneda(valorRestante)} para futuros pagos.`;
      tipoAlerta = 'info';
    } else if (valorRestante === 0 && totalDeudaPendiente > this.model.valor_recibido) {
      mensaje = `El valor de ${this.formatearMoneda(this.model.valor_recibido)} ha sido distribuido completamente entre ${this.cuentasSeleccionadas.length} cuentas.\n\nAún quedan cuentas pendientes por pagar.`;
    } else if (valorRestante === 0 && totalAplicado === totalDeudaPendiente) {
      mensaje = `¡Excelente! El valor de ${this.formatearMoneda(this.model.valor_recibido)} cubre exactamente todas las ${this.cuentasSeleccionadas.length} cuentas pendientes.`;
    } else {
      mensaje = `El valor de ${this.formatearMoneda(this.model.valor_recibido)} ha sido distribuido completamente entre ${this.cuentasSeleccionadas.length} cuentas.`;
    }

    Swal.fire({
      title: 'Distribución automática completada',
      text: mensaje,
      icon: tipoAlerta,
      confirmButtonText: 'Entendido'
    });

    this.actualizarTotales();
  }

  getCuentaAplicadaValor(idCuenta: string): number {
    const cuentaAplicada = this.model.cuentas_aplicadas.find(ca => ca.id_cuenta_por_cobrar === idCuenta);
    return cuentaAplicada ? cuentaAplicada.valor_aplicado : 0;
  }

  esSaldoCompletado(): boolean {
    return this.valorRestante === 0 && this.model.valor_recibido > 0;
  }

  esSaldoPendiente(): boolean {
    return this.valorRestante > 0 && this.model.valor_recibido > 0;
  }

  getEstadoCuenta(cuenta: any): string {
    const fechaCuenta = new Date(cuenta.fecha);
    const fechaHoy = new Date();

    fechaHoy.setHours(0, 0, 0, 0);
    fechaCuenta.setHours(0, 0, 0, 0);

    if (fechaCuenta < fechaHoy && cuenta.valor_pagado === 0) {
      return 'estado-vencido-sin-pago';
    }

    if (fechaCuenta < fechaHoy && cuenta.valor_pagado < cuenta.valor) {
      return 'estado-vencido-pago-parcial';
    }

    return '';
  }

  validarFormularioConDetalles(): { valido: boolean, mensajes: string[] } {
    const errores: string[] = [];

    if (!this.model.fecha) {
      errores.push("Debe seleccionar una fecha válida");
    }

    if (this.model.id_acudiente == "0") {
      errores.push("Debe seleccionar un acudiente");
    }

    if (!this.model.id_tipo_pago) {
      errores.push("Debe seleccionar un tipo de pago");
    }

    if (this.model.valor_recibido <= 0) {
      errores.push("El valor recibido debe ser mayor a cero");
    }

    if (this.cuentasSeleccionadas.length === 0) {
      errores.push("Debe seleccionar al menos una cuenta para aplicar el pago");
    } else {
      const totalAplicado = this.model.cuentas_aplicadas.reduce(
        (sum, ca) => sum + ca.valor_aplicado, 0
      );

      if (totalAplicado <= 0) {
        errores.push("El valor total aplicado no puede ser cero");
      }

      if (totalAplicado > this.model.valor_recibido) {
        errores.push(`El total aplicado (${this.formatearMoneda(totalAplicado)}) excede el valor recibido (${this.formatearMoneda(this.model.valor_recibido)})`);
      }
    }

    if (this.tipoPagoRequiereReferencia() && !this.model.referencia_bancaria) {
      errores.push("Debe ingresar una referencia bancaria para este tipo de pago");
    }

    return {
      valido: errores.length === 0,
      mensajes: errores
    };
  }

  // Determina si el tipo de pago seleccionado exige referencia/comprobante,
  // basándose en la columna requiere_documento del tipo (no en ids fijos).
  tipoPagoRequiereReferencia(): boolean {
    if (!this.model.id_tipo_pago) return false;
    const tipo = this.listas.tiposPago.find((tp: any) => String(tp.id) === String(this.model.id_tipo_pago));
    return tipo ? Number(tipo.requiere_documento) === 1 : false;
  }

  // ============================================
  // COMPROBANTE DE PAGO + IA
  // ============================================

  // Selección del archivo de comprobante. Solo valida y lo guarda en memoria;
  // el análisis con IA se dispara con el botón "Procesar con IA".
  onArchivoComprobanteSeleccionado(event: any): void {
    const file = event.target.files[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      Swal.fire('Error', 'El archivo no puede superar 10MB', 'error');
      event.target.value = '';
      return;
    }

    const extension = file.name.split('.').pop()?.toLowerCase();
    if (!extension || !['pdf', 'jpg', 'jpeg', 'png'].includes(extension)) {
      Swal.fire('Error', 'Solo se permiten archivos PDF, JPG, JPEG o PNG', 'error');
      event.target.value = '';
      return;
    }

    this.archivoComprobante = file;
    // Al cambiar de archivo se reinicia el documento subido previamente.
    this.idDocumentoPersona = null;
    this.bancoDetectadoIA = null;
  }

  // Quita el comprobante seleccionado y limpia el estado asociado.
  quitarComprobante(): void {
    this.archivoComprobante = null;
    this.idDocumentoPersona = null;
    this.bancoDetectadoIA = null;
    this.valorComprobanteIA = null;
    this.referenciaVerificada = null;
    const input = document.getElementById('archivoComprobante') as HTMLInputElement;
    if (input) input.value = '';
  }

  // Indica si el pago cargado (editar/consultar) tiene un comprobante asociado.
  tieneComprobante(): boolean {
    return !!this.model.id_documento_persona;
  }

  // Descarga el comprobante asociado al pago. La descarga (blob por HttpClient,
  // con token y tenant via interceptor) está centralizada en el servicio.
  descargarComprobante(): void {
    if (!this.model.id_documento_persona) return;

    this.documentosService.descargarDocumentoArchivo(this.model.id_documento_persona, 'comprobante');
  }

  // Procesa el comprobante con IA y rellena valor, referencia y fecha.
  // Además compara el banco detectado contra el tipo de pago seleccionado.
  procesarComprobanteIA(): void {
    if (!this.archivoComprobante) {
      Swal.fire('Atención', 'Primero seleccione el archivo del comprobante', 'warning');
      return;
    }

    this.analizandoIA = true;
    this.pagosService.analizarComprobante(this.archivoComprobante).subscribe({
      next: (respuesta: any) => {
        this.analizandoIA = false;
        if (respuesta && respuesta.success && respuesta.datos) {
          const datos = respuesta.datos;

          if (datos.valor) {
            this.model.valor_recibido = Number(datos.valor);
            this.valorComprobanteIA = Number(datos.valor);
            this.formatearValorRecibido(this.model.valor_recibido);
            this.actualizarTotales();
          }
          if (datos.referencia) {
            this.model.referencia_bancaria = String(datos.referencia);
          }
          if (datos.fecha) {
            this.model.fecha = datos.fecha;
          }
          this.bancoDetectadoIA = datos.banco ? String(datos.banco) : null;

          this.validarBancoContraTipoPago();
          // La referencia recién leída se verifica de una vez, sin esperar a grabar.
          this.verificarReferenciaTemprana();
        } else {
          Swal.fire('Advertencia', 'No se pudieron extraer los datos del comprobante. Puede ingresar los datos manualmente.', 'warning');
        }
      },
      error: (error: any) => {
        this.analizandoIA = false;
        console.error('Error al analizar el comprobante:', error);
        Swal.fire('Advertencia', 'No se pudo procesar el comprobante con IA. Puede ingresar los datos manualmente.', 'warning');
      }
    });
  }

  // Reacciona al cambio de tipo de pago. Dos cosas:
  // 1) Si el nuevo tipo no exige comprobante (ej. efectivo), se descarta el
  //    archivo cargado: el bloque se oculta en la vista y no debe subirse.
  // 2) Revalida el banco detectado por la IA, porque el usuario puede procesar
  //    el comprobante antes o despues de elegir el tipo de pago.
  onTipoPagoCambiado(): void {
    if (!this.tipoPagoRequiereReferencia()) {
      this.quitarComprobante();
      return;
    }
    this.validarBancoContraTipoPago();
  }

  // Compara el banco detectado por la IA contra el nombre del tipo de pago
  // seleccionado. Solo advierte (no bloquea) si no parecen coincidir.
  private validarBancoContraTipoPago(): void {
    if (!this.bancoDetectadoIA || !this.model.id_tipo_pago) return;

    const tipo = this.listas.tiposPago.find((tp: any) => String(tp.id) === String(this.model.id_tipo_pago));
    if (!tipo || !tipo.nombre) return;

    const normalizar = (texto: string): string =>
      texto.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();

    const banco = normalizar(this.bancoDetectadoIA);
    const nombreTipo = normalizar(tipo.nombre);

    // Coincide si alguno contiene al otro (ej. "Nequi" vs "Nequi", "Bancolombia" vs "Bancolombia S.A.")
    const coincide = banco.includes(nombreTipo) || nombreTipo.includes(banco);

    if (!coincide) {
      Swal.fire({
        title: 'Verifique el tipo de pago',
        html: `<div style="text-align:left;">`
          + `El comprobante parece ser de <strong>${this.bancoDetectadoIA}</strong>, `
          + `pero el tipo de pago seleccionado es <strong>${tipo.nombre}</strong>.<br><br>`
          + `Verifique que el tipo de pago sea el correcto.`
          + `</div>`,
        icon: 'warning',
        confirmButtonText: 'Entendido'
      });
    }
  }

  // Sube el archivo de comprobante y devuelve el id del documento creado.
  // Si no hay archivo, resuelve con null. Replica el patrón del registro rápido.
  private subirComprobante(): Promise<string | null> {
    return new Promise((resolve, reject) => {
      if (!this.archivoComprobante) {
        resolve(null);
        return;
      }

      const formData = new FormData();
      formData.append('archivo', this.archivoComprobante);
      formData.append('id_persona', this.estudiante?.id_persona?.toString() || '');
      formData.append('codigo_tipo_documento', this.CODIGO_TIPO_DOCUMENTO_COMPROBANTE);
      formData.append('observaciones', `Comprobante de pago - Ref: ${this.model.referencia_bancaria || 'N/A'}`);
      const idUsuario = this.utilService.obtenerIdUsuarioActual();
      if (idUsuario) formData.append('id_usuario_subio', idUsuario.toString());

      this.documentosService.subirDocumento(formData).subscribe({
        next: (response: any) => resolve(response.id || response.body?.id || null),
        error: (error: any) => reject(error)
      });
    });
  }

  // ============================================
  // MÉTODOS DE VERIFICACIÓN DE DUPLICADOS
  // ============================================

  // Verifica la referencia apenas se conoce (tras leer el comprobante con IA o al
  // salir del campo), sin esperar a grabar. La referencia repetida NO es un error:
  // un mismo comprobante puede repartirse entre varios estudiantes (hermanos), así
  // que aquí solo se advierte. El bloqueo por exceso se mantiene en grabar().
  verificarReferenciaTemprana(): void {
    const referencia = (this.model.referencia_bancaria || '').trim();

    // En consulta no hay nada que registrar, así que no se verifica.
    if (!referencia || this.accion === 'consultar') {
      this.referenciaVerificada = null;
      return;
    }

    // Evita repetir la consulta si la referencia no cambió desde la última.
    if (this.referenciaVerificada === referencia) return;
    this.referenciaVerificada = referencia;

    // Solo se envía la referencia: el chequeo de "posible duplicado" del backend
    // no aplica en este momento y así la consulta es más liviana.
    const datos: any = { referencia_bancaria: referencia };
    if (this.accion === 'editar' && this.model.id) {
      datos.id_pago_excluir = this.model.id;
    }

    this.pagosService.verificarDuplicado(datos).subscribe({
      next: (respuesta: any) => {
        const pagosPrevios = (respuesta && respuesta.referencia_existente) ? respuesta.referencia_existente : [];
        if (pagosPrevios.length === 0) return;

        const totalRegistrado = Number(respuesta.total_referencia || 0);
        const valorEstePago = Number(this.model.valor_recibido || 0);
        const valorComprobante = Number(this.valorComprobanteIA || 0);
        const totalAcumulado = totalRegistrado + valorEstePago;

        // Con el comprobante leído por IA se puede comparar contra su valor.
        if (valorComprobante > 0 && totalAcumulado > valorComprobante) {
          Swal.fire({
            title: 'El comprobante no alcanza',
            html: `<div style="text-align:left;">`
              + `Comprobante <strong>${referencia}</strong> por <strong>$${this.formatearMoneda(valorComprobante)}</strong>.<br><br>`
              + `Ya registrado: <strong>$${this.formatearMoneda(totalRegistrado)}</strong><br>`
              + `Este pago: <strong>$${this.formatearMoneda(valorEstePago)}</strong><br>`
              + `Total: <strong>$${this.formatearMoneda(totalAcumulado)}</strong><br><br>`
              + `Excede en <strong>$${this.formatearMoneda(totalAcumulado - valorComprobante)}</strong>. Verifique los valores.`
              + `</div>`,
            icon: 'warning',
            confirmButtonText: 'Entendido',
            width: '520px'
          });
          return;
        }

        // Sin exceso, solo se informa que la referencia ya se usó antes.
        Swal.fire({
          title: 'Referencia ya utilizada',
          html: `<div style="text-align:left;">`
            + `La referencia <strong>${referencia}</strong> ya tiene pagos registrados por `
            + `<strong>$${this.formatearMoneda(totalRegistrado)}</strong>:`
            + this.construirHtmlCoincidencias(pagosPrevios)
            + `<div style="margin-top:8px;">Si el comprobante cubre a varios estudiantes puede continuar.</div>`
            + `</div>`,
          icon: 'info',
          confirmButtonText: 'Entendido',
          width: '520px'
        });
      },
      error: (error: any) => {
        // La verificación es informativa: si falla, no se interrumpe el registro.
        console.error('Error al verificar la referencia:', error);
        this.referenciaVerificada = null;
      }
    });
  }

  // Arma el payload para el endpoint de verificación. En editar se envía el id
  // del pago actual para que no se compare consigo mismo.
  private construirDatosVerificacion(): any {
    const datos: any = {
      referencia_bancaria: this.model.referencia_bancaria || '',
      id_estudiante: this.model.id_estudiante,
      id_tipo_pago: this.model.id_tipo_pago,
      valor_recibido: this.model.valor_recibido,
      fecha: this.model.fecha
    };
    if (this.accion === 'editar' && this.model.id) {
      datos.id_pago_excluir = this.model.id;
    }
    return datos;
  }

  // Construye el HTML del listado de coincidencias para el aviso de duplicados.
  private construirHtmlCoincidencias(coincidencias: any[]): string {
    let html = '<ul style="margin:6px 0 0 0;padding-left:18px;text-align:left;">';
    coincidencias.forEach((c: any) => {
      const nombre = c.nombre_estudiante ? c.nombre_estudiante : 'Estudiante';
      const valor = '$' + this.formatearMoneda(Number(c.valor_recibido));
      const fecha = c.fecha ? String(c.fecha).substring(0, 10) : '';
      const tipo = c.tipo_pago ? c.tipo_pago : '';
      html += `<li style="margin-bottom:4px;">`
        + `<strong>${nombre}</strong><br>`
        + `<span style="color:#555;">${valor}${fecha ? ' &middot; ' + fecha : ''}${tipo ? ' &middot; ' + tipo : ''}</span>`
        + `</li>`;
    });
    html += '</ul>';
    return html;
  }

  formularioValido(): boolean {
    const validacion = this.validarFormularioConDetalles();
    return validacion.valido;
  }

  grabar() {
    this.submitted = true;
    const validacion = this.validarFormularioConDetalles();

    if (!validacion.valido) {
      if (validacion.mensajes.length > 0) {
        Swal.fire('Error de validación', validacion.mensajes[0], 'error');
      }
      return;
    }

    const datosPago = {
      id: this.model.id,
      fecha: this.model.fecha,
      id_estudiante: this.model.id_estudiante,
      id_acudiente: this.model.id_acudiente,
      id_tipo_pago: this.model.id_tipo_pago,
      valor_recibido: this.model.valor_recibido,
      saldo: this.model.saldo,
      observaciones: this.model.observaciones || '',
      referencia_bancaria: this.model.referencia_bancaria || '',
      fecha_registro: new Date().toISOString().replace('T', ' ').substring(0, 19),
      id_usuario_registro: this.model.id_usuario_registro,
      fecha_contabilizacion: null,
      id_usuario_contable: null,
      id_documento_persona: null as string | null
    };

    let cuentasNuevasAplicadas: CuentaAplicadaModel[] = [];

    if (this.accion === 'editar') {
      cuentasNuevasAplicadas = this.model.cuentas_aplicadas
        .filter(cuenta => !cuenta.id && cuenta.valor_aplicado > 0)
        .map(cuenta => ({
          ...cuenta,
          fecha: this.model.fecha
        }));

      console.log('Nuevas cuentas a aplicar en edición:', cuentasNuevasAplicadas);
    } else {
      cuentasNuevasAplicadas = this.model.cuentas_aplicadas.map(cuenta => ({
        ...cuenta,
        fecha: this.model.fecha
      }));
    }

    // Antes de confirmar, verificar posibles duplicados (referencia ya usada y/o
    // pago idéntico). Es solo advertencia: si el usuario acepta, continúa el flujo.
    this.pagosService.verificarDuplicado(this.construirDatosVerificacion()).subscribe({
      next: (respuesta: any) => {
        const referenciaExistente = (respuesta && respuesta.referencia_existente) ? respuesta.referencia_existente : [];
        const posibleDuplicado = (respuesta && respuesta.posible_duplicado) ? respuesta.posible_duplicado : [];

        if (referenciaExistente.length > 0 || posibleDuplicado.length > 0) {
          let html = '<div style="text-align:left;">';
          // Excede el comprobante: no es una duda, es un error de valores.
          // En ese caso no se ofrece continuar.
          let excedeComprobante = false;

          if (posibleDuplicado.length > 0) {
            html += `<div style="margin-bottom:12px;">`
              + `<div style="font-weight:600;color:#d9822b;">⚠ Pago idéntico ya registrado</div>`
              + `<div style="color:#555;font-size:.9em;">Mismo estudiante, tipo, valor y fecha (${posibleDuplicado.length}):</div>`
              + this.construirHtmlCoincidencias(posibleDuplicado)
              + `</div>`;
          }

          if (referenciaExistente.length > 0) {
            const totalRegistrado = Number(respuesta.total_referencia || 0);
            // Un mismo comprobante puede repartirse entre varios estudiantes, por
            // eso se muestra el acumulado y, si la IA leyó el valor, cuánto queda.
            const valorComprobante = Number(this.valorComprobanteIA || 0);
            let detalleTope = '';
            if (valorComprobante > 0) {
              const disponible = valorComprobante - totalRegistrado;
              const nuevoTotal = totalRegistrado + Number(this.model.valor_recibido || 0);
              detalleTope = `<div style="color:#555;font-size:.9em;">`
                + `Comprobante por $${this.formatearMoneda(valorComprobante)} · `
                + `ya registrado $${this.formatearMoneda(totalRegistrado)} · `
                + `disponible $${this.formatearMoneda(disponible)}</div>`;
              if (nuevoTotal > valorComprobante) {
                excedeComprobante = true;
                detalleTope += `<div style="color:#c0392b;font-weight:600;">`
                  + `Con este pago sumaría $${this.formatearMoneda(nuevoTotal)} y excede el comprobante en `
                  + `$${this.formatearMoneda(nuevoTotal - valorComprobante)}.</div>`;
              }
            } else {
              detalleTope = `<div style="color:#555;font-size:.9em;">`
                + `Total ya registrado con esa referencia: $${this.formatearMoneda(totalRegistrado)}</div>`;
            }

            html += `<div style="margin-bottom:12px;">`
              + `<div style="font-weight:600;color:#d9822b;">⚠ Referencia ya registrada</div>`
              + `<div style="color:#555;font-size:.9em;">La referencia "${this.model.referencia_bancaria}" aparece en ${referenciaExistente.length} pago(s):</div>`
              + detalleTope
              + this.construirHtmlCoincidencias(referenciaExistente)
              + `</div>`;
          }

          // Con exceso se bloquea: solo queda corregir el valor.
          if (excedeComprobante) {
            html += `<div style="margin-top:8px;">Corrija el valor recibido para continuar.</div>`;
            html += `</div>`;
            Swal.fire({
              title: 'El comprobante no alcanza',
              html: html,
              icon: 'error',
              confirmButtonText: 'Entendido',
              width: '520px'
            });
            return;
          }

          html += `<div style="margin-top:8px;">¿Desea registrar el pago de todas formas?</div>`;
          html += `</div>`;

          Swal.fire({
            title: 'Posible pago duplicado',
            html: html,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Registrar de todas formas',
            cancelButtonText: 'Cancelar',
            width: '520px'
          }).then((result) => {
            if (result.isConfirmed) {
              this.confirmarYGuardar(datosPago, cuentasNuevasAplicadas);
            }
          });
        } else {
          this.confirmarYGuardar(datosPago, cuentasNuevasAplicadas);
        }
      },
      error: (error: any) => {
        // Si la verificación falla, no se bloquea el registro: se continúa con la confirmación normal.
        console.error('Error al verificar duplicados:', error);
        this.confirmarYGuardar(datosPago, cuentasNuevasAplicadas);
      }
    });
  }

  // Muestra la confirmación final y ejecuta el registro/actualización del pago.
  // Extraído de grabar() para reutilizarlo tras la verificación de duplicados.
  private confirmarYGuardar(datosPago: any, cuentasNuevasAplicadas: CuentaAplicadaModel[]) {
    let mensaje = this.accion === 'crear'
      ? `¿Está seguro de registrar este pago por ${this.formatearMoneda(this.model.valor_recibido)}?`
      : `¿Está seguro de actualizar este pago?`;

    if (this.valorRestante > 0) {
      mensaje += ` Quedará un saldo de ${this.formatearMoneda(this.valorRestante)} a favor del estudiante.`;
    }

    if (this.accion === 'editar' && cuentasNuevasAplicadas.length > 0) {
      const totalNuevasAplicaciones = cuentasNuevasAplicadas.reduce((sum, ca) => sum + ca.valor_aplicado, 0);
      mensaje += ` Se aplicará ${this.formatearMoneda(totalNuevasAplicaciones)} a ${cuentasNuevasAplicadas.length} nueva(s) cuenta(s).`;
    }

    // Informar si se asociará un reporte pendiente
    if (this.reporteSeleccionado) {
      mensaje += ` Se asociará el reporte de pago #${this.reporteSeleccionado.id} por ${this.formatearMoneda(this.reporteSeleccionado.valor)}.`;
    }

    Swal.fire({
      title: 'Confirmación',
      text: mensaje,
      icon: 'question',
      showCancelButton: true,
      confirmButtonText: 'Sí, continuar',
      cancelButtonText: 'No, cancelar'
    }).then((result) => {
      if (result.isConfirmed) {
        console.log('Datos a enviar:', datosPago);

        if (this.accion === 'crear') {
          // Si hay comprobante, subirlo primero y adjuntar su id al pago.
          this.subirComprobante()
            .then((idDocumento: string | null) => {
              this.idDocumentoPersona = idDocumento;
              datosPago.id_documento_persona = idDocumento;

              this.pagosService.crear(datosPago).subscribe({
                next: (respuesta: any) => {
                  console.log('Respuesta del servicio:', respuesta);
                  if (respuesta && respuesta.id) {
                    const idPagoRecibido = respuesta.id;
                    this.asociarReporteAlPago(idPagoRecibido);
                    this.procesarCuentasAplicadas(idPagoRecibido, cuentasNuevasAplicadas);
                  } else {
                    Swal.fire('Error', 'No se pudo registrar el pago correctamente', 'error');
                  }
                },
                error: (error: any) => {
                  console.error('Error al registrar el pago:', error);
                  Swal.fire('Error', 'No se pudo registrar el pago. Verifique los datos e intente nuevamente.', 'error');
                }
              });
            })
            .catch((error: any) => {
              console.error('Error al subir el comprobante:', error);
              Swal.fire('Error', 'No se pudo subir el comprobante. Intente nuevamente.', 'error');
            });
        } else {
          // Modo editar
          this.pagosService.actualizar(datosPago).subscribe({
            next: (respuesta: any) => {
              console.log('Respuesta del servicio de actualización:', respuesta);

              // Asociar reporte de pago si hay uno seleccionado
              this.asociarReporteAlPago(this.model.id);

              if (cuentasNuevasAplicadas.length > 0) {
                this.procesarCuentasAplicadas(this.model.id, cuentasNuevasAplicadas);
              } else {
                Swal.fire({
                  title: 'Pago actualizado con éxito',
                  icon: 'success',
                  confirmButtonText: 'Aceptar'
                }).then(() => {
                  this.volver();
                });
              }
            },
            error: (error: any) => {
              console.error('Error al actualizar el pago:', error);
              Swal.fire('Error', 'No se pudo actualizar el pago. Verifique los datos e intente nuevamente.', 'error');
            }
          });
        }
      }
    });
  }

  procesarCuentasAplicadas(idPagoRecibido: string, cuentasAplicadas: CuentaAplicadaModel[]) {
    if (cuentasAplicadas.length === 0) {
      this.mostrarMensajeExito();
      return;
    }

    const cuentasParaEnviar = cuentasAplicadas.map(cuenta => ({
      id_cuenta_por_cobrar: cuenta.id_cuenta_por_cobrar,
      valor_aplicado: cuenta.valor_aplicado,
      valor_aplicado_mora: cuenta.valor_aplicado_mora || 0,
      fecha: cuenta.fecha
    }));

    console.log(`Procesando ${cuentasParaEnviar.length} cuentas en lote...`);

    this.cuentaPagadaService.crearEnLote(idPagoRecibido, cuentasParaEnviar).subscribe({
      next: (respuesta: any) => {
        console.log('Todas las cuentas aplicadas fueron registradas correctamente:', respuesta);

        if (respuesta.success) {
          this.mostrarMensajeExito();
        } else {
          Swal.fire({
            title: 'Advertencia',
            text: 'El pago se registró pero hubo algunos problemas al aplicar las cuentas. Por favor, revise el detalle del pago.',
            icon: 'warning',
            confirmButtonText: 'Entendido'
          }).then(() => {
            this.mostrarMensajeExito();
          });
        }
      },
      error: (error: any) => {
        console.error('Error al registrar cuentas aplicadas en lote:', error);
      }
    });
  }

  // Método de respaldo por si falla el procesamiento en lote
  procesarCuentasAplicadasIndividual(idPagoRecibido: string, cuentasAplicadas: CuentaAplicadaModel[]) {
    if (cuentasAplicadas.length === 0) {
      this.mostrarMensajeExito();
      return;
    }

    let cuentasProcesadas = 0;
    let errores = 0;

    cuentasAplicadas.forEach(cuenta => {
      const datosAplicacion = {
        id_cuenta_por_cobrar: cuenta.id_cuenta_por_cobrar,
        id_pago_recibido: idPagoRecibido,
        valor_aplicado: cuenta.valor_aplicado,
        fecha: cuenta.fecha
      };

      this.cuentaPagadaService.crear(datosAplicacion).subscribe({
        next: (respuesta: any) => {
          console.log('Cuenta aplicada registrada correctamente:', respuesta);
          cuentasProcesadas++;
          if (cuentasProcesadas + errores === cuentasAplicadas.length) {
            this.verificarCompletado(errores);
          }
        },
        error: (error: any) => {
          console.error('Error al registrar cuenta aplicada:', error);
          errores++;
          if (cuentasProcesadas + errores === cuentasAplicadas.length) {
            this.verificarCompletado(errores);
          }
        }
      });
    });
  }

  verificarCompletado(errores: number) {
    if (errores > 0) {
      Swal.fire({
        title: 'Advertencia',
        text: `El pago se registró pero hubo ${errores} errores al registrar las cuentas aplicadas.`,
        icon: 'warning',
        confirmButtonText: 'Entendido'
      }).then(() => {
        this.mostrarMensajeExito();
      });
    } else {
      this.mostrarMensajeExito();
    }
  }

  mostrarMensajeExito() {
    Swal.fire({
      title: this.accion === 'crear' ? 'Pago registrado con éxito' : 'Pago actualizado',
      icon: 'success',
      confirmButtonText: 'Aceptar'
    }).then(() => {
      if (this.accion === 'crear') {
        this.limpiarFormulario();
      } else {
        this.volver();
      }
    });
  }

  limpiarFormulario() {
    this.model = {
      id: '',
      fecha: "",
      id_estudiante: "",
      id_acudiente: "",
      id_tipo_pago: "",
      valor_recibido: 0,
      saldo: 0,
      observaciones: "",
      referencia_bancaria: "",
      id_usuario_registro: null,
      cuentas_aplicadas: []
    };
    const hoy = new Date();
    this.model.fecha = hoy.toISOString().split('T')[0];
    this.model.id_estudiante = this.idEstudiante;
    this.model.id_usuario_registro = this.utilService.obtenerIdUsuarioActual();
    this.cuentasSeleccionadas = [];
    this.submitted = false;
    this.valorRestante = 0;
    this.valorRecibidoFormateado = '';
    this.valoresAplicadosFormateados = {};
    this.reporteSeleccionado = null;
    this.reportesPendientes = [];
    this.archivoComprobante = null;
    this.idDocumentoPersona = null;
    this.bancoDetectadoIA = null;
    this.analizandoIA = false;
    const inputComprobante = document.getElementById('archivoComprobante') as HTMLInputElement;
    if (inputComprobante) inputComprobante.value = '';
    this.cargarReportesPendientes();
    this.obtenerCuentasPorCobrar();

    if (this.listas.acudientes.length > 0) {
      this.model.id_acudiente = this.listas.acudientes[0].id;
    }
  }

  formatearFechaCompleta(dateString: string | null | undefined): string {
    if (!dateString) return '';

    const date = new Date(dateString);
    const opciones: Intl.DateTimeFormatOptions = {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    };

    return date.toLocaleDateString('es-CO', opciones);
  }

  volver() {
    this.router.navigate([this.regresar]);
  }

  // ============================================
  // MÉTODOS PARA REPORTES DE PAGO
  // ============================================

  cargarReportesPendientes(): void {
    if (!this.idEstudiante || this.idEstudiante === '0') return;

    this.reportesPagoService.obtenerPendientesByEstudiante(this.idEstudiante).subscribe({
      next: (response: any) => {
        this.reportesPendientes = response.body || [];
        console.log('Reportes pendientes cargados:', this.reportesPendientes.length);
      },
      error: (error: any) => {
        console.error('Error al cargar reportes pendientes:', error);
        this.reportesPendientes = [];
      }
    });
  }

  cargarReporteAsociado(): void {
    setTimeout(() => {
      if (!this.id || this.id === '0') return;

      this.reportesPagoService.obtenerByPagoRecibido(this.id).subscribe({
        next: (response: any) => {
          const reportes = response.body || [];
          if (reportes.length > 0) {
            this.reporteAsociado = reportes[0];
            console.log('Reporte asociado encontrado:', this.reporteAsociado);
          } else {
            // No hay reporte asociado: cargar pendientes para poder asociar uno
            this.reporteAsociado = null;
            if (this.accion === 'editar') {
              this.cargarReportesPendientes();
            }
          }
        },
        error: (error: any) => {
          console.error('Error al cargar reporte asociado:', error);
          // En caso de error, también intentar cargar pendientes en editar
          if (this.accion === 'editar') {
            this.cargarReportesPendientes();
          }
        }
      });
    }, 500);
  }

  seleccionarReporte(reporte: any): void {
    if (this.reporteSeleccionado?.id === reporte.id) {
      this.deseleccionarReporte();
      return;
    }

    this.reporteSeleccionado = reporte;

    // Solo pre-llenar datos en modo crear (en editar el pago ya existe)
    if (this.accion === 'crear') {
      this.model.valor_recibido = Number(reporte.valor);
      this.formatearValorRecibido(this.model.valor_recibido);
      this.model.id_tipo_pago = String(reporte.id_tipo_pago);
      this.model.fecha = reporte.fecha_pago;
      this.actualizarTotales();
    }

    console.log('Reporte seleccionado:', reporte.id, '- Valor:', reporte.valor);
  }

  deseleccionarReporte(): void {
    this.reporteSeleccionado = null;
  }

  asociarReporteAlPago(idPagoRecibido: string): void {
    if (!this.reporteSeleccionado) return;

    this.reportesPagoService.asociarPago({
      id: this.reporteSeleccionado.id,
      id_pago_recibido: idPagoRecibido
    }).subscribe({
      next: () => {
        console.log('Reporte de pago asociado correctamente al pago:', idPagoRecibido);
      },
      error: (error: any) => {
        console.error('Error al asociar reporte de pago:', error);
      }
    });
  }

  obtenerUrlComprobante(ruta: string): string {
    if (!ruta) return '';
    const baseUrl = environment.api.replace(/\/api\/?$/, '/');
    return baseUrl + ruta;
  }
}